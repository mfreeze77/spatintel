# Requirements coverage report

Generated: `2026-07-27T19:08:23.380513+00:00`

Total normative requirements: **1,028**

| Priority | EXTERNAL_VALIDATION_REQUIRED | IMPLEMENTED_UNVERIFIED | IN_PROGRESS | NOT_STARTED | VERIFIED | Total |
|---|---:|---:|---:|---:|---:|---:|
| P0 | 1 | 31 | 16 | 430 | 26 | 504 |
| P1 | 3 | 19 | 4 | 479 | 19 | 524 |

Verified: **45**
External validation required: **4**
Blocked: **0**

> Absence from the verified count is not evidence of implementation. Release-mode specification lint remains fail-closed.
