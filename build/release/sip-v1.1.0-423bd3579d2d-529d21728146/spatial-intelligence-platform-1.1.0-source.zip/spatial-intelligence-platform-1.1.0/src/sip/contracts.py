from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator, model_validator

from .models import Audience, AuthorityClass, Classification, RepresentationKind, SourceClass


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class HashRef(ContractModel):
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    byte_count: int = Field(ge=0)
    media_type: str


class CoordinateFrameContract(ContractModel):
    frame_id: str
    parent_frame_id: str | None = None
    convention: Literal["right_handed_y_up_meters", "right_handed_z_up_meters", "source_native"]
    units: Literal["meter", "millimeter"] = "meter"
    transform_to_parent: list[list[float]] | None = None
    uncertainty_m: float | None = Field(default=None, ge=0)

    @field_validator("transform_to_parent")
    @classmethod
    def matrix_is_4x4(cls, value: list[list[float]] | None) -> list[list[float]] | None:
        if value is not None and (len(value) != 4 or any(len(row) != 4 for row in value)):
            raise ValueError("transform_to_parent must be 4x4")
        return value


class CaptureAssetContract(HashRef):
    asset_id: str
    relative_path: str
    role: str
    immutable: bool = True
    encryption: dict[str, Any] | None = None


class CaptureFrameContract(ContractModel):
    frame_id: str
    timestamp_ns: int = Field(ge=0)
    coordinate_frame_id: str
    rgb_asset_id: str
    depth_asset_id: str | None = None
    confidence_asset_id: str | None = None
    camera_pose: list[list[float]]
    intrinsics: list[list[float]]
    tracking_state: str
    exposure: dict[str, float] = Field(default_factory=dict)
    quality: dict[str, float] = Field(default_factory=dict)
    restricted_region_ids: list[str] = Field(default_factory=list)

    @field_validator("camera_pose")
    @classmethod
    def pose_is_4x4(cls, value: list[list[float]]) -> list[list[float]]:
        if len(value) != 4 or any(len(row) != 4 for row in value):
            raise ValueError("camera_pose must be 4x4")
        return value

    @field_validator("intrinsics")
    @classmethod
    def intrinsics_is_3x3(cls, value: list[list[float]]) -> list[list[float]]:
        if len(value) != 3 or any(len(row) != 3 for row in value):
            raise ValueError("intrinsics must be 3x3")
        return value


class CaptureRootContract(ContractModel):
    schema_name: Literal["sip.cscp"] = Field(default="sip.cscp", alias="schema", serialization_alias="schema")
    schema_version: str = "1.1.0"
    package_id: str
    created_at: datetime
    capture_profile: str
    source_adapter: str
    native_source_hash: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    coordinate_frames: list[CoordinateFrameContract] = Field(min_length=1)
    assets: list[CaptureAssetContract]
    frames: list[CaptureFrameContract]
    policy: dict[str, Any]
    journal_root_hash: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    merkle_root: str = Field(pattern=r"^[a-f0-9]{64}$")


class EventEnvelopeContract(ContractModel):
    event_id: str
    event_type: str
    schema_version: str
    tenant_id: str
    project_id: str | None = None
    aggregate_type: str
    aggregate_id: str
    occurred_at: datetime
    actor_id: str | None = None
    trace_id: str | None = None
    causation_id: str | None = None
    correlation_id: str | None = None
    payload: dict[str, Any]
    payload_hash: str = Field(pattern=r"^[a-f0-9]{64}$")


class OperationContract(ContractModel):
    operation_id: str
    tenant_id: str
    project_id: str
    operation_type: str
    idempotency_key: str
    state: Literal["pending", "leased", "running", "succeeded", "failed", "cancel_requested", "cancelled", "quarantined"]
    progress: float = Field(ge=0, le=1)
    attempt: int = Field(ge=0)
    max_attempts: int = Field(ge=1)
    input_manifest_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
    checkpoint: dict[str, Any]
    output_hash: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    error: dict[str, Any]


class ProviderManifestContract(ContractModel):
    provider_id: str
    version: str
    provider_class: Literal["local_open_source", "private_managed", "external_api", "manual_external", "research_shadow"]
    source_url: str
    source_revision: str
    image_digest: str | None = None
    license_id: str
    approval_state: Literal["approved", "denied", "expired", "revoked", "research_only", "pending"]
    allowed_classifications: list[Classification]
    allowed_purposes: list[str]
    allowed_regions: list[str]
    deployments: list[str] = Field(default_factory=list)
    retention_days: int | None = Field(default=None, ge=0)
    output_rights: str
    expires_at: datetime | None = None
    manifest_hash: str = Field(pattern=r"^[a-f0-9]{64}$")


class LicenseDocumentContract(ContractModel):
    component: Literal["code", "weights", "dataset", "hosted_service", "output"]
    title: str = Field(min_length=1, max_length=256)
    license_id: str = Field(min_length=1, max_length=128)
    source_url: str = Field(min_length=1, max_length=2048)
    document_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    review_state: Literal["verified", "missing", "pending", "incompatible"]


class ManifestRestrictionContract(ContractModel):
    mode: Literal["unrestricted", "allowlist", "denylist"]
    values: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_values(self) -> "ManifestRestrictionContract":
        normalized = [value.strip() for value in self.values]
        if any(not value for value in normalized):
            raise ValueError("restriction values must be non-empty")
        if len(set(normalized)) != len(normalized):
            raise ValueError("restriction values must be unique")
        if self.mode == "unrestricted" and normalized:
            raise ValueError("unrestricted restrictions cannot contain values")
        if self.mode in {"allowlist", "denylist"} and not normalized:
            raise ValueError(f"{self.mode} restrictions require at least one value")
        self.values = normalized
        return self


class ModelManifestContract(ContractModel):
    schema_name: Literal["sip.model-manifest/v1.1"] = Field(
        default="sip.model-manifest/v1.1", alias="schema", serialization_alias="schema"
    )
    schema_version: Literal["1.1.0"] = "1.1.0"
    model_id: str = Field(min_length=1, max_length=128)
    provider: str = Field(min_length=1, max_length=256)
    model_name: str = Field(min_length=1, max_length=256)
    version: str = Field(min_length=1, max_length=64)
    revision: str = Field(min_length=1, max_length=128)
    checkpoint_hash: str = Field(min_length=1, max_length=128)
    source_urls: list[str] = Field(min_length=1)
    license_documents: list[LicenseDocumentContract] = Field(min_length=1)
    code_revision: str = Field(min_length=1, max_length=128)
    code_license: str = Field(min_length=1, max_length=128)
    weights_license: str = Field(min_length=1, max_length=128)
    dataset_terms: list[str] = Field(min_length=1)
    output_terms: str = Field(min_length=1)
    approval_state: Literal["approved", "denied", "expired", "revoked", "research_only", "pending"]
    commercial_use: bool
    allowed_classifications: list[Classification] = Field(min_length=1)
    permitted_uses: list[str] = Field(min_length=1)
    prohibited_uses: list[str] = Field(min_length=1)
    geographic_restrictions: ManifestRestrictionContract
    customer_restrictions: ManifestRestrictionContract
    allowed_deployments: list[Literal["development", "test", "staging", "production"]] = Field(min_length=1)
    approved_by: str = Field(min_length=1, max_length=128)
    reviewed_at: datetime
    review_due_at: datetime
    expires_at: datetime | None = None
    revoked_at: datetime | None = None
    manifest_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
    manifest_signature: str = Field(pattern=r"^[a-f0-9]{64}$")
    signed_by: str = Field(min_length=1, max_length=128)

    @field_validator(
        "source_urls", "dataset_terms", "permitted_uses", "prohibited_uses", "allowed_deployments"
    )
    @classmethod
    def lists_are_nonempty_unique(cls, value: list[str]) -> list[str]:
        normalized = [item.strip() for item in value]
        if any(not item for item in normalized):
            raise ValueError("manifest list entries must be non-empty")
        if len(set(normalized)) != len(normalized):
            raise ValueError("manifest list entries must be unique")
        return normalized

    @model_validator(mode="after")
    def validate_policy_dates_and_uses(self) -> "ModelManifestContract":
        if set(self.permitted_uses) & set(self.prohibited_uses):
            raise ValueError("permitted and prohibited uses cannot overlap")
        if self.review_due_at <= self.reviewed_at:
            raise ValueError("review_due_at must be after reviewed_at")
        if self.expires_at is not None and self.expires_at <= self.reviewed_at:
            raise ValueError("expires_at must be after reviewed_at")
        if self.approval_state == "revoked" and self.revoked_at is None:
            raise ValueError("revoked manifests require revoked_at")
        if self.approval_state != "revoked" and self.revoked_at is not None:
            raise ValueError("revoked_at is only valid for revoked manifests")
        return self


class RepresentationAssetContract(ContractModel):
    representation_id: str
    scene_id: str
    asset_id: str
    kind: RepresentationKind
    provider_id: str
    provider_version: str
    coordinate_frame_id: str
    source_class: SourceClass
    authority_class: AuthorityClass
    authority_ceiling: AuthorityClass
    disposable: bool
    lossy: bool
    intended_uses: list[str]
    prohibited_uses: list[str]
    quality: dict[str, Any]
    provenance: dict[str, Any]
    support_map: dict[str, Any]
    state: Literal["quarantined", "quality_failed", "approved", "published", "superseded"]

    @model_validator(mode="after")
    def enforce_representation_authority(self) -> "RepresentationAssetContract":
        if self.kind == RepresentationKind.INTERACTION:
            if self.authority_class != AuthorityClass.DERIVED_NON_AUTHORITATIVE:
                raise ValueError("interaction representations require derived_non_authoritative authority")
            if self.authority_ceiling != AuthorityClass.DERIVED_NON_AUTHORITATIVE:
                raise ValueError("interaction representations require a derived_non_authoritative authority ceiling")
            if not self.disposable:
                raise ValueError("interaction representations must be disposable")
        if self.kind == RepresentationKind.VISUAL and self.authority_ceiling in {
            AuthorityClass.METRIC,
            AuthorityClass.FIELD_VERIFIED,
        }:
            raise ValueError("visual representations cannot have metric or field-verified authority ceilings")
        return self


class SceneEntityContract(ContractModel):
    entity_id: str
    scene_id: str
    entity_type: str
    name: str
    source_class: SourceClass
    authority_class: AuthorityClass
    confidence: float = Field(ge=0, le=1)
    attributes: dict[str, Any]
    provenance: dict[str, Any]
    policy: dict[str, Any]
    stable_support: dict[str, Any]


class MeasurementContract(ContractModel):
    measurement_id: str
    entity_id: str | None
    value: float
    unit: str
    uncertainty: float = Field(ge=0)
    source_asset_ids: list[str] = Field(min_length=1)
    calibration: dict[str, Any]
    verifier_id: str | None
    verification_date: datetime | None
    authority_class: AuthorityClass
    warning: str = "Phone-derived geometry is not survey-grade or contract-authoritative without independent verification."


class ConsentGrantContract(ContractModel):
    grant_id: str
    subject_id: str
    granted_by: str
    purposes: list[str]
    audiences: list[Audience]
    scopes: list[str]
    derivative_policy: dict[str, Any]
    expires_at: datetime | None
    state: Literal["active", "revoked", "expired"]
    revocation_propagation_required: bool = True


class PreservationManifestContract(ContractModel):
    format: Literal["sip-open-preservation"] = "sip-open-preservation"
    format_version: str = "1.1.0"
    tenant_id: str
    project_id: str
    assets: list[dict[str, Any]]
    tables: dict[str, list[dict[str, Any]]]
    semantic_identity: dict[str, Any]
    files: list[HashRef]
    root_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
