from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select

from .audit import AuditService
from .canonical import canonical_sha256, new_uuid
from .database import (
    Database,
    ProviderManifestRow,
    OutboxEventRow,
    RepresentationAssetRow,
    RepresentationBindingRow,
    SceneCommitRow,
)
from .errors import AuthorizationError, ConflictError, NotFoundError, ValidationError
from .models import AuthorityClass, Classification, RepresentationKind, SourceClass
from .temporal import db_now


class ProviderRegistry:
    def __init__(self, database: Database, audit: AuditService) -> None:
        self.database = database
        self.audit = audit

    def register(self, manifest: dict[str, Any], *, actor_id: str) -> dict[str, Any]:
        required = {
            "provider_id",
            "version",
            "source_url",
            "source_revision",
            "license_id",
            "approval_state",
            "allowed_classifications",
            "allowed_purposes",
            "allowed_regions",
        }
        missing = sorted(required - manifest.keys())
        if missing:
            raise ValidationError("PROVIDER_MANIFEST_INCOMPLETE", "provider manifest is incomplete", {"missing": missing})
        body = {key: manifest[key] for key in sorted(manifest) if key not in {"manifest_hash", "signature"}}
        digest = canonical_sha256(body)
        provider_id = manifest["provider_id"]
        with self.database.session() as session:
            row = session.get(ProviderManifestRow, provider_id)
            values = dict(
                provider_id=provider_id,
                version=manifest["version"],
                source_url=manifest["source_url"],
                source_revision=manifest["source_revision"],
                image_digest=manifest.get("image_digest"),
                license_id=manifest["license_id"],
                approval_state=manifest["approval_state"],
                allowed_classifications_json=manifest["allowed_classifications"],
                allowed_purposes_json=manifest["allowed_purposes"],
                allowed_regions_json=manifest["allowed_regions"],
                retention_days=manifest.get("retention_days"),
                expires_at=_parse_datetime(manifest.get("expires_at")),
                manifest_hash=digest,
                signed_by=manifest.get("signed_by", actor_id),
            )
            if row:
                for key, value in values.items():
                    setattr(row, key, value)
            else:
                session.add(ProviderManifestRow(**values))
        return {"provider_id": provider_id, "manifest_hash": digest, "approval_state": manifest["approval_state"]}

    def authorize_execution(
        self,
        provider_id: str,
        *,
        classification: Classification,
        purpose: str,
        region: str,
        external: bool,
    ) -> dict[str, Any]:
        with self.database.session() as session:
            row = session.get(ProviderManifestRow, provider_id)
            if not row:
                raise AuthorizationError("PROVIDER_NOT_REGISTERED", "provider execution is denied because no approved manifest exists")
            now = db_now()
            expiry = _aware(row.expires_at) if row.expires_at else None
            reasons: list[str] = []
            if row.approval_state != "approved":
                reasons.append("not_approved")
            if expiry and expiry <= now:
                reasons.append("approval_expired")
            if classification.value not in row.allowed_classifications_json:
                reasons.append("classification_not_allowed")
            if purpose not in row.allowed_purposes_json:
                reasons.append("purpose_not_allowed")
            if region not in row.allowed_regions_json:
                reasons.append("region_not_allowed")
            if external and classification in {Classification.CRITICAL_INFRASTRUCTURE, Classification.BIOMETRIC, Classification.MINOR}:
                reasons.append("sensitive_external_processing_denied")
            if reasons:
                raise AuthorizationError("PROVIDER_EXECUTION_DENIED", "provider manifest does not permit this execution", {"reasons": reasons})
            return {
                "allowed": True,
                "provider_id": provider_id,
                "provider_version": row.version,
                "source_revision": row.source_revision,
                "image_digest": row.image_digest,
                "manifest_hash": row.manifest_hash,
                "retention_days": row.retention_days,
            }


class RepresentationService:
    def __init__(self, database: Database, audit: AuditService) -> None:
        self.database = database
        self.audit = audit

    def create_candidate(
        self,
        *,
        tenant_id: str,
        project_id: str,
        scene_id: str,
        asset_id: str,
        kind: RepresentationKind,
        provider_id: str,
        coordinate_frame_id: str,
        source_class: SourceClass,
        authority_class: AuthorityClass,
        lossy: bool,
        intended_uses: list[str],
        prohibited_uses: list[str],
        quality: dict[str, Any],
        provenance: dict[str, Any],
        support_map: dict[str, Any],
        actor_id: str,
        operation_id: str | None = None,
        representation_id: str | None = None,
    ) -> str:
        if kind == RepresentationKind.INTERACTION and authority_class != AuthorityClass.DERIVED_NON_AUTHORITATIVE:
            raise ValidationError(
                "INTERACTION_AUTHORITY_INVALID",
                "interaction proxies must carry the exact derived_non_authoritative authority class",
            )
        if kind == RepresentationKind.VISUAL and authority_class in {AuthorityClass.METRIC, AuthorityClass.FIELD_VERIFIED}:
            raise ValidationError("VISUAL_AUTHORITY_INVALID", "visual representations cannot carry metric authority")
        if kind == RepresentationKind.METRIC and source_class == SourceClass.GENERATED and authority_class == AuthorityClass.FIELD_VERIFIED:
            raise ValidationError("GENERATED_VERIFICATION_INVALID", "generated geometry cannot be field verified by confidence alone")
        representation_id = representation_id or new_uuid()
        with self.database.session() as session:
            if operation_id:
                existing = session.scalar(
                    select(RepresentationAssetRow).where(
                        RepresentationAssetRow.tenant_id == tenant_id,
                        RepresentationAssetRow.project_id == project_id,
                        RepresentationAssetRow.operation_id == operation_id,
                    )
                )
                if existing:
                    if (
                        existing.scene_id != scene_id
                        or existing.asset_id != asset_id
                        or existing.kind != kind.value
                        or existing.coordinate_frame_id != coordinate_frame_id
                        or existing.provider_id != provider_id
                        or existing.source_class != source_class.value
                        or existing.authority_class != authority_class.value
                        or existing.lossy != lossy
                        or existing.intended_uses_json != intended_uses
                        or existing.prohibited_uses_json != prohibited_uses
                        or canonical_sha256(existing.provenance_json) != canonical_sha256(provenance)
                    ):
                        raise ConflictError(
                            "REPRESENTATION_OPERATION_CONFLICT",
                            "operation is already bound to a different representation candidate",
                        )
                    if existing.representation_id != representation_id:
                        raise ConflictError(
                            "REPRESENTATION_IDEMPOTENCY_CONFLICT",
                            "operation candidate identifier does not match the durable candidate",
                        )
                    return existing.representation_id
            duplicate_id = session.get(RepresentationAssetRow, representation_id)
            if duplicate_id is not None:
                raise ConflictError(
                    "REPRESENTATION_ID_CONFLICT",
                    "representation identifier is already bound to another candidate",
                    {"representation_id": representation_id},
                )
            session.add(
                RepresentationAssetRow(
                    representation_id=representation_id,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    asset_id=asset_id,
                    operation_id=operation_id,
                    kind=kind.value,
                    provider_id=provider_id,
                    coordinate_frame_id=coordinate_frame_id,
                    source_class=source_class.value,
                    authority_class=authority_class.value,
                    authority_ceiling=(
                        AuthorityClass.DERIVED_NON_AUTHORITATIVE.value
                        if kind == RepresentationKind.INTERACTION
                        else authority_class.value
                    ),
                    disposable=kind == RepresentationKind.INTERACTION,
                    lossy=lossy,
                    intended_uses_json=intended_uses,
                    prohibited_uses_json=prohibited_uses,
                    quality_json=quality,
                    provenance_json=provenance,
                    support_map_json=support_map,
                    state="quarantined",
                )
            )
            event_payload = {
                "candidate_id": representation_id,
                "representation_id": representation_id,
                "operation_id": operation_id,
                "asset_id": asset_id,
                "kind": kind.value,
                "provider_id": provider_id,
                "state": "quarantined",
            }
            session.add(
                OutboxEventRow(
                    event_id=new_uuid(),
                    tenant_id=tenant_id,
                    project_id=project_id,
                    event_type="RepresentationCandidateCreated",
                    schema_version="1.1.0",
                    aggregate_type="representation_candidate",
                    aggregate_id=representation_id,
                    payload_json=event_payload,
                    payload_hash=canonical_sha256(event_payload),
                )
            )
            self.audit.append(
                tenant_id=tenant_id,
                project_id=project_id,
                actor_id=actor_id,
                action="representation:candidate_create",
                resource_type="representation",
                resource_id=representation_id,
                outcome="allowed",
                details={"kind": kind.value, "provider_id": provider_id, "state": "quarantined"},
                session=session,
            )
        return representation_id


    def attach_worker_receipt(
        self,
        *,
        tenant_id: str,
        project_id: str,
        operation_id: str,
        worker_receipt_hash: str,
        candidate_core_hash: str,
        actor_id: str,
    ) -> dict[str, Any]:
        """Bind exact worker evidence to a still-quarantined candidate idempotently."""
        with self.database.session() as session:
            row = session.scalar(
                select(RepresentationAssetRow).where(
                    RepresentationAssetRow.tenant_id == tenant_id,
                    RepresentationAssetRow.project_id == project_id,
                    RepresentationAssetRow.operation_id == operation_id,
                )
            )
            if row is None:
                raise NotFoundError("representation_candidate_for_operation", operation_id)
            if row.state != "quarantined":
                raise ConflictError(
                    "REPRESENTATION_RECEIPT_STATE_CONFLICT",
                    "worker evidence can only be attached while a candidate is quarantined",
                    {"state": row.state},
                )
            provenance = dict(row.provenance_json or {})
            existing_core = provenance.get("candidate_core_hash")
            if existing_core and existing_core != candidate_core_hash:
                raise ConflictError(
                    "REPRESENTATION_RECEIPT_CONFLICT",
                    "candidate is already bound to a different immutable candidate core",
                )
            receipts = list(provenance.get("worker_receipts") or [])
            evidence = {
                "worker_receipt_hash": worker_receipt_hash,
                "candidate_core_hash": candidate_core_hash,
            }
            if evidence not in receipts:
                receipts.append(evidence)
            provenance.update(
                {
                    "worker_receipt_hash": worker_receipt_hash,
                    "candidate_core_hash": candidate_core_hash,
                    "worker_receipts": receipts,
                }
            )
            row.provenance_json = provenance
            self.audit.append(
                tenant_id=tenant_id,
                project_id=project_id,
                actor_id=actor_id,
                action="representation:worker_receipt_attach",
                resource_type="representation",
                resource_id=row.representation_id,
                outcome="allowed",
                details={
                    "operation_id": operation_id,
                    "worker_receipt_hash": worker_receipt_hash,
                    "candidate_core_hash": candidate_core_hash,
                },
                session=session,
            )
            return {
                "representation_id": row.representation_id,
                "worker_receipt_hash": worker_receipt_hash,
                "candidate_core_hash": candidate_core_hash,
            }


    def candidate_for_operation(self, *, tenant_id: str, project_id: str, operation_id: str) -> dict[str, Any] | None:
        """Return the idempotent candidate created by a durable operation, if any."""
        with self.database.session() as session:
            row = session.scalar(
                select(RepresentationAssetRow).where(
                    RepresentationAssetRow.tenant_id == tenant_id,
                    RepresentationAssetRow.project_id == project_id,
                    RepresentationAssetRow.operation_id == operation_id,
                )
            )
            if row is None:
                return None
            return {
                "representation_id": row.representation_id,
                "asset_id": row.asset_id,
                "state": row.state,
                "kind": row.kind,
                "operation_id": row.operation_id,
                "scene_id": row.scene_id,
                "provider_id": row.provider_id,
                "coordinate_frame_id": row.coordinate_frame_id,
                "source_class": row.source_class,
                "authority_class": row.authority_class,
                "authority_ceiling": row.authority_ceiling,
                "disposable": row.disposable,
                "lossy": row.lossy,
                "intended_uses": row.intended_uses_json,
                "prohibited_uses": row.prohibited_uses_json,
                "quality": row.quality_json,
                "provenance": row.provenance_json,
                "support_map": row.support_map_json,
            }

    def review_quality(
        self,
        representation_id: str,
        *,
        reviewer_id: str,
        approved_uses: list[str],
        metrics: dict[str, Any],
        passed: bool,
    ) -> dict[str, Any]:
        with self.database.session() as session:
            row = session.get(RepresentationAssetRow, representation_id)
            if not row:
                raise NotFoundError("representation", representation_id)
            if reviewer_id.startswith("sip-worker:"):
                raise AuthorizationError(
                    "WORKER_REVIEWER_NOT_INDEPENDENT",
                    "a representation-producing worker cannot independently approve its own output",
                )
            if row.state not in {"quarantined", "quality_failed"}:
                raise ConflictError("REPRESENTATION_REVIEW_STATE", "representation cannot be reviewed in its current state")
            provenance = dict(row.provenance_json or {})
            if row.operation_id and not (
                provenance.get("worker_receipt_hash") and provenance.get("candidate_core_hash")
            ):
                raise ConflictError(
                    "REPRESENTATION_WORKER_EVIDENCE_MISSING",
                    "worker-derived candidates require an immutable receipt before quality review",
                )
            unrequested = sorted(set(approved_uses) - set(row.intended_uses_json))
            if unrequested:
                raise ValidationError("REPRESENTATION_USE_NOT_REQUESTED", "review cannot approve unrequested use", {"uses": unrequested})
            if passed and (not approved_uses or not metrics):
                raise ValidationError(
                    "REPRESENTATION_REVIEW_EVIDENCE_INCOMPLETE",
                    "a passing independent review requires approved uses and retained quantitative metrics",
                )
            row.quality_json = {
                **row.quality_json,
                "review": {
                    "reviewer_id": reviewer_id,
                    "approved_uses": sorted(set(approved_uses)),
                    "metrics": metrics,
                    "reviewed_at": db_now().isoformat(),
                    "independent_from_worker": True,
                },
            }
            row.state = "approved" if passed else "quality_failed"
            self.audit.append(
                tenant_id=row.tenant_id,
                project_id=row.project_id,
                actor_id=reviewer_id,
                action="representation:quality_review",
                resource_type="representation",
                resource_id=row.representation_id,
                outcome="allowed",
                details={
                    "passed": passed,
                    "approved_uses": sorted(set(approved_uses)) if passed else [],
                    "metrics_hash": canonical_sha256(metrics),
                },
                session=session,
            )
            return {
                "representation_id": representation_id,
                "state": row.state,
                "approved_uses": sorted(set(approved_uses)) if passed else [],
            }

    def replace_proxy(self, old_representation_id: str, new_representation_id: str) -> dict[str, Any]:
        with self.database.session() as session:
            old = session.get(RepresentationAssetRow, old_representation_id)
            new = session.get(RepresentationAssetRow, new_representation_id)
            if not old or not new or old.kind != "interaction" or new.kind != "interaction":
                raise ValidationError("PROXY_REPLACEMENT_INVALID", "both representations must be interaction proxies")
            if old.scene_id != new.scene_id or old.coordinate_frame_id != new.coordinate_frame_id:
                raise ValidationError("PROXY_REPLACEMENT_FRAME_MISMATCH", "proxy replacement must remain in the same scene and coordinate frame")
            anchors = old.support_map_json.get("anchors", [])
            supported = set(new.support_map_json.get("semantic_support_ids", []))
            reprojected = [anchor for anchor in anchors if anchor.get("semantic_support_id") in supported]
            unresolved = [anchor for anchor in anchors if anchor.get("semantic_support_id") not in supported]
            new.support_map_json = {**new.support_map_json, "anchors": reprojected, "replaces": old_representation_id}
            old.state = "superseded"
            return {
                "old_representation_id": old_representation_id,
                "new_representation_id": new_representation_id,
                "reprojected": len(reprojected),
                "unresolved": len(unresolved),
                "reprojected_anchor_ids": [item.get("anchor_id") for item in reprojected],
                "unresolved_anchors": unresolved,
            }


class RepresentationPublisher:
    """The only service allowed to attach a reviewed representation to a scene commit."""

    def __init__(self, database: Database, audit: AuditService) -> None:
        self.database = database
        self.audit = audit

    def publish(
        self,
        representation_id: str,
        *,
        commit_id: str,
        role: str,
        publisher_id: str,
    ) -> str:
        if publisher_id.startswith("sip-worker:"):
            raise AuthorizationError(
                "WORKER_PUBLICATION_DENIED",
                "worker workload identities have no representation publication permission",
            )
        with self.database.session() as session:
            rep = session.get(RepresentationAssetRow, representation_id)
            commit = session.get(SceneCommitRow, commit_id)
            if not rep:
                raise NotFoundError("representation", representation_id)
            if not commit or commit.tenant_id != rep.tenant_id or commit.project_id != rep.project_id or commit.scene_id != rep.scene_id:
                raise ValidationError("REPRESENTATION_COMMIT_SCOPE_MISMATCH", "representation and commit do not share scope")
            if rep.state != "approved":
                raise ConflictError("REPRESENTATION_NOT_APPROVED", "only quality-approved candidates may be published")
            provider = session.get(ProviderManifestRow, rep.provider_id)
            provider_expiry = _aware(provider.expires_at) if provider and provider.expires_at else None
            if provider is None or provider.approval_state != "approved" or (provider_expiry and provider_expiry <= db_now()):
                raise AuthorizationError(
                    "PROVIDER_PUBLICATION_DENIED",
                    "representation publication is denied because its provider is not currently approved",
                )
            admitted_manifest_hash = (rep.provenance_json or {}).get("provider_manifest_hash")
            if admitted_manifest_hash and admitted_manifest_hash != provider.manifest_hash:
                raise AuthorizationError(
                    "PROVIDER_MANIFEST_CHANGED",
                    "provider policy changed after computation; the candidate must be re-admitted and reviewed",
                )
            if role in set(rep.prohibited_uses_json):
                raise AuthorizationError("REPRESENTATION_USE_PROHIBITED", "requested publication role is prohibited")
            reviewed = set(rep.quality_json.get("review", {}).get("approved_uses", []))
            if role not in reviewed:
                raise AuthorizationError("REPRESENTATION_USE_NOT_APPROVED", "requested publication role was not independently approved")
            prior = list(
                session.scalars(
                    select(RepresentationBindingRow).where(
                        RepresentationBindingRow.tenant_id == rep.tenant_id,
                        RepresentationBindingRow.project_id == rep.project_id,
                        RepresentationBindingRow.scene_id == rep.scene_id,
                        RepresentationBindingRow.role == role,
                        RepresentationBindingRow.superseded_at.is_(None),
                    )
                )
            )
            now = db_now()
            for binding in prior:
                binding.superseded_at = now
            binding_id = new_uuid()
            session.add(
                RepresentationBindingRow(
                    binding_id=binding_id,
                    tenant_id=rep.tenant_id,
                    project_id=rep.project_id,
                    scene_id=rep.scene_id,
                    commit_id=commit_id,
                    representation_id=representation_id,
                    role=role,
                    published_by=publisher_id,
                )
            )
            rep.state = "published"
            self.audit.append(
                tenant_id=rep.tenant_id,
                project_id=rep.project_id,
                actor_id=publisher_id,
                action="representation:publish",
                resource_type="representation_binding",
                resource_id=binding_id,
                outcome="allowed",
                details={"representation_id": representation_id, "commit_id": commit_id, "role": role},
                session=session,
            )
            return binding_id


def _parse_datetime(value: str | datetime | None) -> datetime | None:
    if value is None or isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _aware(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=UTC)
