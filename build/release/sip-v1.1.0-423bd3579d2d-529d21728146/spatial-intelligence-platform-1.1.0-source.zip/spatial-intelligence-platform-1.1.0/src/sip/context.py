from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .assets import AssetService, ContentAddressedStore, LocalContentAddressedStore, S3ContentAddressedStore
from .audit import AuditService
from .collaboration import CollaborationService, NotificationService
from .config import Settings
from .construction import ConstructionService
from .database import Database
from .exporting import PreservationService
from .lifecycle import AdmissionController, BackupRecoveryService, KeyRotationService, LifecycleService
from .liveforever import LiveForeverService
from .model_governance import ModelRegistry
from .operations import OperationService
from .policy import PolicyService
from .representations import ProviderRegistry, RepresentationPublisher, RepresentationService
from .scene import SceneService
from .search import SearchService
from .security import EnvelopeCipher, SignedTokenCodec
from .tenancy import TenancyService


@dataclass
class PlatformContext:
    settings: Settings
    database: Database
    store: ContentAddressedStore
    audit: AuditService
    assets: AssetService
    tenancy: TenancyService
    policy: PolicyService
    operations: OperationService
    preservation: PreservationService
    lifecycle: LifecycleService
    backup_recovery: BackupRecoveryService
    key_rotation: KeyRotationService
    admission: AdmissionController
    scene: SceneService
    providers: ProviderRegistry
    representations: RepresentationService
    publisher: RepresentationPublisher
    models: ModelRegistry
    construction: ConstructionService
    liveforever: LiveForeverService
    search: SearchService
    collaboration: CollaborationService
    notifications: NotificationService

    @classmethod
    def create(cls, settings: Settings | None = None, *, create_schema: bool | None = None) -> "PlatformContext":
        settings = settings or Settings.from_env()
        if create_schema is None:
            create_schema = settings.environment in {"development", "test"} and settings.database_url.startswith("sqlite")
        database = Database(settings.database_url, create=create_schema)
        cipher = EnvelopeCipher(settings.master_key, settings.master_key_id)
        if settings.object_store_backend == "local":
            store: ContentAddressedStore = LocalContentAddressedStore(settings.object_store_root, cipher)
        else:
            import boto3

            client = boto3.client(
                "s3",
                region_name=settings.s3_region,
                endpoint_url=settings.s3_endpoint_url,
            )
            store = S3ContentAddressedStore(
                bucket=settings.s3_bucket or "",
                prefix=settings.s3_prefix,
                cipher=cipher,
                client=client,
                kms_key_id=settings.s3_kms_key_id,
            )
        audit = AuditService(database, settings.signing_key)
        token_codec = SignedTokenCodec(settings.signing_key)
        assets = AssetService(database, store, audit, token_codec, multipart_root=settings.multipart_root)
        preservation = PreservationService(database, assets)
        return cls(
            settings=settings,
            database=database,
            store=store,
            audit=audit,
            assets=assets,
            tenancy=TenancyService(database, audit),
            policy=PolicyService(database, audit),
            operations=OperationService(database, audit),
            preservation=preservation,
            lifecycle=LifecycleService(database, assets, audit),
            backup_recovery=BackupRecoveryService(database, preservation, assets, audit),
            key_rotation=KeyRotationService(database, assets, audit),
            admission=AdmissionController(database, audit),
            scene=SceneService(database, audit),
            providers=ProviderRegistry(database, audit),
            representations=RepresentationService(database, audit),
            publisher=RepresentationPublisher(database, audit),
            models=ModelRegistry(database, settings.signing_key),
            construction=ConstructionService(database, audit),
            liveforever=LiveForeverService(database, audit),
            search=SearchService(database),
            collaboration=CollaborationService(database),
            notifications=NotificationService(database),
        )


def temporary_settings(root: Path) -> Settings:
    return Settings(
        environment="test",
        database_url=f"sqlite:///{root / 'sip.sqlite3'}",
        object_store_backend="local",
        object_store_root=root / "objects",
        multipart_root=root / "multipart",
        s3_bucket=None,
        s3_prefix="sip-test",
        s3_region=None,
        s3_endpoint_url=None,
        s3_kms_key_id=None,
        master_key=b"m" * 32,
        master_key_id="test-master-v1",
        signing_key=b"a" * 32,
        allow_development_auth=True,
    )
