from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy import func, select

from sip.canonical import canonical_sha256, sha256_bytes
from sip.context import PlatformContext, temporary_settings
from sip.database import (
    AssetRefRow,
    AuditEventRow,
    CollaborationCommentRow,
    CollaborationTaskRow,
    ConsentGrantRow,
    ConstructionRecordRow,
    CoordinateFrameRow,
    LegalHoldRow,
    MeasurementRow,
    ProviderManifestRow,
    RepresentationAssetRow,
    RepresentationBindingRow,
    RetentionRuleRow,
    SceneBranchRow,
    SceneCommitRow,
    SceneEntityRow,
    SearchDocumentRow,
)
from sip.models import Audience, AuthorityClass, Classification, ProvenanceRef, RepresentationKind, SourceClass


@pytest.mark.integration
@pytest.mark.acceptance
def test_pltio_foundation_open_export_collision_safe_import_preserves_hash_and_semantic_identity(bootstrapped, tmp_path: Path) -> None:
    """REQ: PLTIO-003, PLTIO-012 preservation import retains source hashes and reconstructs semantic scene identity without private vendor knowledge."""
    context, tenant_id, project_id, actor = bootstrapped
    payload = b"open-preservation-source"
    asset = context.assets.ingest_bytes(
        tenant_id=tenant_id,
        project_id=project_id,
        data=payload,
        media_type="application/octet-stream",
        original_name="source.bin",
        classification=Classification.INTERNAL,
        retention_class="preservation",
        source_class=SourceClass.DIRECT_CAPTURE,
        authority_class=AuthorityClass.EVIDENCE,
        provenance=ProvenanceRef(source_ids=["fixture"], output_hash=sha256_bytes(payload)),
        actor_id=actor,
    )
    scene = context.scene.create_scene(tenant_id, project_id, name="Export room", actor_id=actor)
    package_path = tmp_path / "project.sip-preservation.zip"
    package = context.preservation.export_project(tenant_id, project_id, package_path, actor_id=actor)
    verified = context.preservation.verify_export(package_path)
    assert verified["root_hash"] == package["root_hash"]
    restored = context.preservation.import_project(
        package_path,
        new_tenant_id="tenant-restored",
        new_project_id="project-restored",
        actor_id="restore-operator",
    )
    assert restored["source_root_hash"] == package["root_hash"]
    assert restored["native_replay"] is True
    # The source and destination share one database, so globally keyed rows must be
    # remapped while project-scoped scene identity remains stable.
    assert restored["id_maps"]["asset"][asset.asset_id] != asset.asset_id
    assert restored["id_maps"]["commit"][scene["commit_id"]] != scene["commit_id"]
    assert restored["scene_id"] == scene["scene_id"]
    with context.database.session() as session:
        restored_refs = list(session.scalars(select(AssetRefRow).where(AssetRefRow.project_id == "project-restored")))
        restored_commits = list(session.scalars(select(SceneCommitRow).where(SceneCommitRow.project_id == "project-restored")))
        restored_branches = list(session.scalars(select(SceneBranchRow).where(SceneBranchRow.project_id == "project-restored")))
    # One source object plus the immutable preservation package master are retained.
    assert len(restored_refs) == 2
    content_ref = next(row for row in restored_refs if row.sha256 == asset.sha256)
    assert context.assets.read("tenant-restored", "project-restored", content_ref.asset_id, actor_id="restore-operator") == payload
    assert len(restored_commits) == 1
    assert restored_commits[0].semantic_snapshot_json["scene_id"] == scene["scene_id"]
    assert restored_commits[0].snapshot_hash == canonical_sha256(restored_commits[0].semantic_snapshot_json)
    assert restored_branches[0].head_commit_id == restored_commits[0].commit_id
    assert restored["preservation_package_asset_id"] in {row.asset_id for row in restored_refs}


@pytest.mark.integration
@pytest.mark.acceptance
@pytest.mark.privacy
def test_open_preservation_clean_restore_rehydrates_authoritative_rows_and_fails_closed_for_executable_state(bootstrapped, tmp_path: Path) -> None:
    """REQ: PLTIO-003, PLTIO-006, PLTIO-012, OPSDR-005 clean restore reconciles native records and keeps executable/governance state fail-closed."""
    source, tenant_id, project_id, actor = bootstrapped
    payload = b"verified preservation evidence"
    evidence = source.assets.ingest_bytes(
        tenant_id=tenant_id,
        project_id=project_id,
        data=payload,
        media_type="application/octet-stream",
        original_name="evidence.bin",
        classification=Classification.CONFIDENTIAL,
        retention_class="records",
        source_class=SourceClass.VERIFIED,
        authority_class=AuthorityClass.EVIDENCE,
        provenance=ProvenanceRef(source_ids=["test-fixture"], output_hash=sha256_bytes(payload)),
        actor_id=actor,
    )
    with source.database.session() as session:
        session.add(
            CoordinateFrameRow(
                frame_id="frame-world-preservation",
                tenant_id=tenant_id,
                project_id=project_id,
                name="World",
                parent_frame_id=None,
                convention="right-handed-y-up",
                units="meter",
                transform_json=None,
                uncertainty_m=0.002,
            )
        )
    provider = source.providers.register(
        {
            "provider_id": "local-preservation-provider",
            "version": "1.0.0",
            "source_url": "local://preservation-test",
            "source_revision": "fixture-v1",
            "license_id": "Apache-2.0",
            "approval_state": "approved",
            "allowed_classifications": ["internal", "confidential"],
            "allowed_purposes": ["preservation-test"],
            "allowed_regions": ["local"],
            "retention_days": 0,
        },
        actor_id=actor,
    )
    scene = source.scene.create_scene(tenant_id, project_id, name="Preserved Scene", actor_id=actor)
    entity = source.scene.create_entity(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        entity_type="fire_alarm_panel",
        name="FACP-1",
        attributes={"location": "Electrical 101"},
        source_class=SourceClass.OBSERVED,
        authority_class=AuthorityClass.EVIDENCE,
        confidence=1.0,
        provenance=ProvenanceRef(source_ids=[evidence.asset_id], output_hash=evidence.sha256),
        policy={"audience": "project", "classification": "confidential"},
        stable_support={"frame_id": "frame-world-preservation", "point": [1.0, 1.5, 0.0]},
        actor_id=actor,
    )
    representation = source.representations.create_candidate(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        asset_id=evidence.asset_id,
        kind=RepresentationKind.METRIC,
        provider_id="local-preservation-provider",
        coordinate_frame_id="frame-world-preservation",
        source_class=SourceClass.MEASURED,
        authority_class=AuthorityClass.METRIC,
        lossy=False,
        intended_uses=["measurement"],
        prohibited_uses=["survey"],
        quality={"uncertainty_m": 0.002},
        provenance={"source_ids": [evidence.asset_id], "provider_manifest_hash": provider["manifest_hash"]},
        support_map={"entity_ids": [entity]},
        actor_id=actor,
    )
    source.representations.review_quality(
        representation,
        reviewer_id="independent-reviewer",
        approved_uses=["measurement"],
        metrics={"rmse_m": 0.001},
        passed=True,
    )
    binding = source.publisher.publish(representation, commit_id=scene["commit_id"], role="measurement", publisher_id="publisher")
    final_commit = source.scene.commit(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        branch="main",
        expected_head=scene["commit_id"],
        message="Preservation-ready metric state",
        actor_id=actor,
    )
    measurement = source.scene.create_measurement(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        entity_id=entity,
        value=1.52,
        unit="m",
        uncertainty=0.003,
        source_asset_ids=[evidence.asset_id],
        calibration={"asset_id": evidence.asset_id, "certificate": "SYN-CAL-001"},
        verifier_id="field-verifier",
        verified=True,
        actor_id=actor,
        originating_representation_id=representation,
    )
    site = source.construction.create_hierarchy_item(
        tenant_id=tenant_id,
        project_id=project_id,
        record_type="site",
        name="Synthetic Campus",
        parent_id=None,
        state="observed",
        actor_id=actor,
    )
    building = source.construction.create_hierarchy_item(
        tenant_id=tenant_id,
        project_id=project_id,
        record_type="building",
        name="Building A",
        parent_id=site,
        state="observed",
        actor_id=actor,
    )
    level = source.construction.create_hierarchy_item(
        tenant_id=tenant_id,
        project_id=project_id,
        record_type="level",
        name="Level 1",
        parent_id=building,
        state="observed",
        actor_id=actor,
    )
    room = source.construction.create_hierarchy_item(
        tenant_id=tenant_id,
        project_id=project_id,
        record_type="room",
        name="Electrical 101",
        parent_id=level,
        state="observed",
        actor_id=actor,
    )
    construction_record = source.construction.create_system_record(
        tenant_id=tenant_id,
        project_id=project_id,
        system_type="fire_alarm_panel",
        parent_id=room,
        entity_id=entity,
        state="verified",
        data={"verified_by": "field-verifier", "photo_asset_id": evidence.asset_id},
        evidence_asset_ids=[evidence.asset_id],
        actor_id=actor,
    )
    subject = "person-preservation-subject"
    consent = source.liveforever.grant_consent(
        tenant_id=tenant_id,
        project_id=project_id,
        subject_id=subject,
        granted_by="subject",
        purposes=["preservation"],
        audiences=[Audience.PRIVATE, Audience.FAMILY],
        scopes=["*"],
        derivative_policy={"generated_visual": False, "voice": False},
        expires_at=datetime.now(UTC) + timedelta(days=365),
    )
    memory = source.liveforever.create_record(
        tenant_id=tenant_id,
        project_id=project_id,
        record_type="person",
        subject_id=subject,
        related_ids=[],
        data={"name": "Preservation Person", "portrait_asset_id": evidence.asset_id},
        source_class=SourceClass.CORROBORATED,
        confidence=0.95,
        evidence_asset_ids=[evidence.asset_id],
        audience=Audience.FAMILY,
        actor_id=actor,
    )
    comment = source.collaboration.comment(
        tenant_id=tenant_id,
        project_id=project_id,
        body="Verify the panel location.",
        author_id=actor,
        scene_commit_id=final_commit["commit_id"],
        entity_id=entity,
    )
    task = source.collaboration.create_task(
        tenant_id=tenant_id,
        project_id=project_id,
        title="Review panel evidence",
        description="Confirm evidence and measurement.",
        created_by=actor,
        entity_id=entity,
        assignee_id="reviewer",
        priority="high",
    )
    retention = source.lifecycle.set_retention_rule(
        tenant_id=tenant_id,
        project_id=project_id,
        retention_class="records",
        policy_source="synthetic policy",
        minimum_days=365,
        maximum_days=None,
        backup_expiry_days=30,
        deletion_mode="manual_review",
        actor_id=actor,
    )
    hold = source.lifecycle.place_hold(
        tenant_id,
        project_id,
        "asset",
        evidence.asset_id,
        reason="preservation test",
        authority_reference="SYN-HOLD-001",
        actor_id=actor,
    )
    source.search.index(
        tenant_id=tenant_id,
        project_id=project_id,
        text="Fire alarm panel in Electrical 101",
        entity_id=entity,
        asset_id=evidence.asset_id,
        embedding=[1.0, 0.0],
        spatial_bounds={"min": [0, 0, 0], "max": [2, 2, 2]},
        temporal_start=None,
        temporal_end=None,
        policy={"audience": "project"},
    )

    package_path = tmp_path / "native.sip-preservation.zip"
    exported = source.preservation.export_project(tenant_id, project_id, package_path, actor_id=actor)
    verified = source.preservation.verify_export(package_path)
    assert verified["metadata"]["domain_schema_version"] == "1.1.0"
    assert "search_documents" in verified["metadata"]["archived_records"]["tables"]
    assert "provider_manifests" in verified["metadata"]["preserved_governance"]["tables"]

    destination = PlatformContext.create(temporary_settings(tmp_path / "clean-restore"))
    result = destination.preservation.import_project(
        package_path,
        new_tenant_id="tenant-clean-restored",
        new_project_id="project-clean-restored",
        actor_id="restore-operator",
    )
    assert result["native_replay"] is True
    assert result["source_root_hash"] == exported["root_hash"]
    # A clean restore preserves stable semantic identifiers.
    assert result["id_maps"]["asset"][evidence.asset_id] == evidence.asset_id
    assert result["id_maps"]["entity"][entity] == entity
    assert result["id_maps"]["representation"][representation] == representation
    assert result["id_maps"]["commit"][final_commit["commit_id"]] == final_commit["commit_id"]
    assert result["id_maps"]["measurement"][measurement] == measurement
    assert result["id_maps"]["construction"][construction_record] == construction_record
    assert result["id_maps"]["memory"][memory] == memory
    assert result["id_maps"]["consent"][consent] == consent
    assert result["id_maps"]["comment"][comment] == comment
    assert result["id_maps"]["task"][task] == task
    assert result["id_maps"]["retention_rule"][retention] == retention
    assert result["id_maps"]["legal_hold"][hold] == hold

    technical = destination.construction.technical_report("tenant-clean-restored", "project-clean-restored")
    assert technical["record_counts"]["fire_alarm_panel"] == 1
    assert any(item["measurement_id"] == measurement and item["verifier_id"] == "field-verifier" for item in technical["measurements"])
    family = destination.liveforever.edition(
        "tenant-clean-restored",
        "project-clean-restored",
        audience=Audience.FAMILY,
        purpose="preservation",
    )
    assert {item["record_id"] for item in family["records"]} == {memory}
    with destination.database.session() as session:
        assert session.get(CoordinateFrameRow, "frame-world-preservation") is not None
        assert session.get(SceneEntityRow, entity).stable_support_json["frame_id"] == "frame-world-preservation"
        assert session.get(RepresentationAssetRow, representation).asset_id == evidence.asset_id
        assert session.get(RepresentationAssetRow, representation).provenance_json["preservation_import"]["provider_reapproval_required_for_new_execution"] is True
        assert session.get(RepresentationBindingRow, binding).commit_id == scene["commit_id"]
        assert session.get(MeasurementRow, measurement).calibration_json["asset_id"] == evidence.asset_id
        assert session.get(ConstructionRecordRow, construction_record).parent_id == room
        assert session.get(ConsentGrantRow, consent).state == "active"
        assert session.get(CollaborationCommentRow, comment).scene_commit_id == final_commit["commit_id"]
        assert session.get(CollaborationTaskRow, task).entity_id == entity
        assert session.get(RetentionRuleRow, retention).project_id == "project-clean-restored"
        restored_hold = session.get(LegalHoldRow, hold)
        assert restored_hold.resource_id == evidence.asset_id and restored_hold.state == "active"
        assert session.get(AssetRefRow, evidence.asset_id).legal_hold is True
        assert session.scalar(select(func.count()).select_from(SearchDocumentRow)) == 0
        assert session.scalar(select(func.count()).select_from(ProviderManifestRow)) == 0
        # Original audit rows are retained in the package, not inserted into the new
        # signing chain. Only destination-native import evidence may exist here.
        destination_audits = list(session.scalars(select(AuditEventRow)))
        assert destination_audits and all(row.action == "asset:ingest" for row in destination_audits)
        package_ref = session.get(AssetRefRow, result["preservation_package_asset_id"])
        assert package_ref is not None and package_ref.retention_class == "preservation_master"
    assert destination.assets.read(
        "tenant-clean-restored",
        "project-clean-restored",
        result["preservation_package_asset_id"],
        actor_id="restore-verifier",
    ) == package_path.read_bytes()
    assert result["non_activated_evidence"]["provider_model_reapproval_required"] is True
    assert result["non_activated_evidence"]["security_bindings_replayed"] is False
    assert result["non_activated_evidence"]["search_reindex_required"] is True
