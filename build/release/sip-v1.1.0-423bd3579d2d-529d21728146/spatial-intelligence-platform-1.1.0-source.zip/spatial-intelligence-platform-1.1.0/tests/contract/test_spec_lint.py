from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from sip.spec_lint import run

ROOT = Path(__file__).resolve().parents[2]


def test_spec_lint_indexes_every_normative_requirement() -> None:
    """REQ: GOVDOC-001 every normative requirement remains uniquely indexed and source-addressable."""
    report = run(release=False)
    assert report["status"] == "passed", report["findings"][:20]
    assert report["spec_requirements"] == 1028
    assert report["ledger_requirements"] == 1028


def test_requirements_outputs_are_queryable_and_have_controlled_test_plans() -> None:
    """REQ: TSTSTRAT-001, TSTSTRAT-002 requirements traceability is machine-readable and queryable."""
    ledger = json.loads((ROOT / "requirements/requirements-ledger.json").read_text())
    assert len(ledger["documents"]) == 164
    assert len(ledger["requirements"]) == 1028
    plans = list((ROOT / "tests/spec/requirements").glob("*.yaml"))
    assert len(plans) == 1028
    with sqlite3.connect(ROOT / "requirements/requirements-ledger.sqlite") as connection:
        count = connection.execute("SELECT COUNT(*) FROM requirements").fetchone()[0]
        p0 = connection.execute("SELECT COUNT(*) FROM requirements WHERE priority='P0'").fetchone()[0]
    assert count == 1028
    assert p0 == 504


def test_release_spec_gate_fails_closed_on_unverified_requirements() -> None:
    """REQ: TSTGATE-003 production promotion is denied while mandatory requirements lack evidence."""
    report = run(release=True)
    assert report["status"] == "failed"
    assert any(item["code"] == "RELEASE_REQUIREMENT_INCOMPLETE" for item in report["findings"])


def test_traceability_overlay_is_generated_and_never_auto_promotes_all_tested_requirements() -> None:
    """REQ: TSTSTRAT-001 evidence overlays remain deterministic and conservative."""
    import importlib.util
    import sys

    path = ROOT / "tools/build_traceability_map.py"
    spec = importlib.util.spec_from_file_location("sip_traceability_map_tool", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    expected = module.build()
    actual = json.loads((ROOT / "requirements/implementation-map.json").read_text(encoding="utf-8"))
    assert actual == expected
    statuses = {item["implementation_status"] for item in actual["requirements"].values()}
    assert "VERIFIED" in statuses
    assert {"IN_PROGRESS", "IMPLEMENTED_UNVERIFIED", "EXTERNAL_VALIDATION_REQUIRED"} <= statuses
    assert len(actual["requirements"]) < 1028


def test_test_matrix_evidence_records_version_environment_inputs_outputs_and_thresholds() -> None:
    """REQ: TSTSTRAT-002 retained automated evidence binds source, environment, inputs, outputs, and pass thresholds."""
    report = json.loads((ROOT / "build/reports/test-matrix.json").read_text(encoding="utf-8"))
    assert report["schema"] == "sip.test-matrix/v2"
    evidence = report["evidence"]
    assert len(evidence["git_commit"]) == 40
    assert len(evidence["source_tree_root_sha256"]) == 64
    assert len(evidence["dependency_snapshot_sha256"]) == 64
    assert evidence["python_version"] and evidence["platform"]
    assert report["verification_policy"] == {
        "required_exit_code": 0,
        "maximum_failures": 0,
        "maximum_errors": 0,
        "manual_reviewer": None,
    }
    # The matrix report is itself consumed while the contract suite is running.
    # Validate that the retained attempt is internally honest instead of creating
    # a circular bootstrap requirement that the current suite already be passed.
    suites_passed = all(
        suite["status"] == "passed"
        and suite["exit_code"] == 0
        and suite["failures"] == 0
        and suite["errors"] == 0
        for suite in report["results"]
    )
    assert report["status"] == ("passed" if suites_passed else "failed")
    for suite in report["results"]:
        assert len(suite["input_root_sha256"]) == 64
        assert len(suite["junit_sha256"]) == 64
        assert len(suite["log_sha256"]) == 64
        if suite["status"] == "passed":
            assert suite["exit_code"] == 0
        else:
            assert suite["exit_code"] != 0
