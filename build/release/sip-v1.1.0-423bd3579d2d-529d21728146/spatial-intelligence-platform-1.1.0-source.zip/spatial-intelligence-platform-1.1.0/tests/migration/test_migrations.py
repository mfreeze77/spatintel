from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
from pathlib import Path

import pytest

from sip.database import Base

ROOT = Path(__file__).parents[2]


def _alembic(database: Path, *args: str, extra_env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["alembic", "-c", "alembic.ini", *args],
        cwd=ROOT,
        env={
            **os.environ,
            "PYTHONPATH": "src",
            "SIP_DATABASE_URL": f"sqlite:///{database}",
            **(extra_env or {}),
        },
        text=True,
        capture_output=True,
        check=False,
    )


@pytest.mark.migration
def test_clean_install_reaches_head_and_matches_canonical_tables(tmp_path: Path) -> None:
    """REQ: DATDB-004, DELDOD-002 clean installation reaches the append-only schema head."""
    database = tmp_path / "clean.sqlite3"
    result = _alembic(database, "upgrade", "head")
    assert result.returncode == 0, result.stdout + result.stderr
    connection = sqlite3.connect(database)
    actual = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    expected = set(Base.metadata.tables)
    assert expected <= actual
    assert actual - expected == {"alembic_version"}
    assert connection.execute("SELECT version_num FROM alembic_version").fetchone()[0] == "0007_representation_authority_contract"


@pytest.mark.migration
def test_upgrade_from_foundation_preserves_immutable_identifiers_and_hashes(tmp_path: Path) -> None:
    """REQ: SIPMIG-001, SIPMIG-006 additive upgrade preserves source hashes and stable identifiers."""
    database = tmp_path / "upgrade.sqlite3"
    assert _alembic(database, "upgrade", "0001_foundation_control_plane").returncode == 0
    connection = sqlite3.connect(database)
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("INSERT INTO tenants(tenant_id,name,status,created_at) VALUES (?,?,?,CURRENT_TIMESTAMP)", ("tenant-upgrade", "Upgrade", "active"))
    connection.execute(
        "INSERT INTO projects(project_id,tenant_id,name,vertical,classification,status,created_at) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP)",
        ("project-upgrade", "tenant-upgrade", "Upgrade", "platform", "internal", "active"),
    )
    digest = "a" * 64
    connection.execute(
        "INSERT INTO assets(sha256,byte_count,media_type,storage_key,encryption_metadata,created_at) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)",
        (digest, 5, "application/octet-stream", digest, "{}"),
    )
    connection.execute(
        "INSERT INTO asset_refs(asset_id,tenant_id,project_id,sha256,original_name,classification,retention_class,source_class,authority_class,provenance_json,legal_hold,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
        ("asset-upgrade", "tenant-upgrade", "project-upgrade", digest, "source.bin", "internal", "preservation", "direct_capture", "evidence", "{}", 0, "fixture"),
    )
    connection.commit()
    connection.close()
    result = _alembic(database, "upgrade", "head")
    assert result.returncode == 0, result.stdout + result.stderr
    connection = sqlite3.connect(database)
    assert connection.execute("SELECT sha256 FROM asset_refs WHERE asset_id='asset-upgrade'").fetchone()[0] == digest
    assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


@pytest.mark.migration
def test_upgrade_reclassifies_legacy_interaction_representations_without_promoting_others(tmp_path: Path) -> None:
    """REQ: RECHYB-002, DATHYB-004 migration applies the exact proxy authority ceiling and disposable marker."""
    database = tmp_path / "authority-upgrade.sqlite3"
    assert _alembic(database, "upgrade", "0006_operation_trace_context").returncode == 0
    connection = sqlite3.connect(database)
    common = (
        "tenant", "project", "scene", "asset", None, "provider", "frame",
        "generated", 1, "[]", "[]", "{}", "{}", "{}", "quarantined",
    )
    connection.execute(
        "INSERT INTO representations("
        "representation_id,tenant_id,project_id,scene_id,asset_id,operation_id,kind,provider_id,"
        "coordinate_frame_id,source_class,authority_class,lossy,intended_uses_json,prohibited_uses_json,"
        "quality_json,provenance_json,support_map_json,state,created_at"
        ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
        ("proxy-legacy", *common[:5], "interaction", *common[5:7], common[7], "interaction", *common[8:]),
    )
    connection.execute(
        "INSERT INTO representations("
        "representation_id,tenant_id,project_id,scene_id,asset_id,operation_id,kind,provider_id,"
        "coordinate_frame_id,source_class,authority_class,lossy,intended_uses_json,prohibited_uses_json,"
        "quality_json,provenance_json,support_map_json,state,created_at"
        ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
        ("metric-existing", *common[:5], "metric", *common[5:7], "inferred", "metric", *common[8:]),
    )
    connection.commit()
    connection.close()

    result = _alembic(database, "upgrade", "head")
    assert result.returncode == 0, result.stdout + result.stderr
    connection = sqlite3.connect(database)
    proxy = connection.execute(
        "SELECT authority_class,authority_ceiling,disposable FROM representations WHERE representation_id='proxy-legacy'"
    ).fetchone()
    metric = connection.execute(
        "SELECT authority_class,authority_ceiling,disposable FROM representations WHERE representation_id='metric-existing'"
    ).fetchone()
    assert proxy == ("derived_non_authoritative", "derived_non_authoritative", 1)
    assert metric == ("metric", "metric", 0)


@pytest.mark.migration
def test_destructive_downgrade_is_denied_by_default_and_rehearsable_only_explicitly(tmp_path: Path) -> None:
    """REQ: DATDB-004 destructive rollback is denied by default and only runs as an explicit recovery rehearsal."""
    database = tmp_path / "downgrade.sqlite3"
    assert _alembic(database, "upgrade", "head").returncode == 0
    denied = _alembic(database, "downgrade", "-1")
    assert denied.returncode != 0
    assert "destructive downgrade denied" in denied.stderr
    rehearsed = _alembic(database, "downgrade", "base", extra_env={"SIP_ALLOW_DESTRUCTIVE_DOWNGRADE": "1"})
    assert rehearsed.returncode == 0, rehearsed.stdout + rehearsed.stderr


@pytest.mark.migration
def test_append_only_migration_manifest_matches_bytes() -> None:
    """REQ: SIPMIG-001 migration history is append-only and every retained migration byte is integrity-locked."""
    manifest = json.loads((ROOT / "migrations" / "manifest.json").read_text())
    assert manifest["append_only"] is True
    revisions = []
    for item in manifest["migrations"]:
        path = ROOT / item["path"]
        payload = path.read_bytes()
        assert len(payload) == item["byte_count"]
        assert hashlib.sha256(payload).hexdigest() == item["sha256"]
        revisions.append(path.stem.split("_", 1)[0])
    assert revisions == ["0001", "0002", "0003", "0004", "0005", "0006", "0007"]
