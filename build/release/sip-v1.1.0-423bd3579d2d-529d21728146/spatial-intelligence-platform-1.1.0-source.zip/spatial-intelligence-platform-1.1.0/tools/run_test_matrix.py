#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import os
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
REPORT_ROOT = ROOT / "build" / "reports" / "tests"


@dataclass(frozen=True)
class SuiteResult:
    name: str
    command: list[str]
    status: str
    exit_code: int
    elapsed_seconds: float
    tests: int
    failures: int
    errors: int
    skipped: int
    junit_path: str
    log_path: str
    input_root_sha256: str
    junit_sha256: str
    log_sha256: str


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    return _sha256_bytes(path.read_bytes()) if path.is_file() else ""


def _hash_path_set(paths: Sequence[str]) -> str:
    records: list[bytes] = []
    for configured in sorted(paths):
        candidate = ROOT / configured
        files = [candidate] if candidate.is_file() else sorted(candidate.rglob("test_*.py"))
        for path in files:
            relative = path.relative_to(ROOT).as_posix().encode("utf-8")
            records.append(relative + b"\0" + hashlib.sha256(path.read_bytes()).digest())
    for configuration in (ROOT / "pytest.ini", ROOT / "pyproject.toml"):
        records.append(configuration.relative_to(ROOT).as_posix().encode("utf-8") + b"\0" + hashlib.sha256(configuration.read_bytes()).digest())
    return _sha256_bytes(b"\n".join(records))


def _source_tree_root() -> str:
    excluded = {".git", "build", "runtime", ".pytest_cache", "__pycache__", "node_modules", ".swiftpm", ".build"}
    names = {"Dockerfile", "Makefile", "justfile", "package.json", "pnpm-workspace.yaml", "pytest.ini", "pyproject.toml"}
    suffixes = {".py", ".json", ".yaml", ".yml", ".toml", ".md", ".swift", ".ts", ".tsx", ".js", ".mjs", ".proto", ".sql"}
    records: list[bytes] = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or any(part in excluded for part in path.relative_to(ROOT).parts):
            continue
        if path.name not in names and path.suffix.lower() not in suffixes:
            continue
        records.append(path.relative_to(ROOT).as_posix().encode("utf-8") + b"\0" + hashlib.sha256(path.read_bytes()).digest())
    return _sha256_bytes(b"\n".join(records))


def _git_value(*args: str) -> str:
    result = subprocess.run(["git", *args], cwd=ROOT, text=True, capture_output=True, check=False)
    return result.stdout.strip() if result.returncode == 0 else "UNAVAILABLE"


def _environment_evidence() -> dict[str, object]:
    freeze = subprocess.run([sys.executable, "-m", "pip", "freeze", "--all"], cwd=ROOT, text=True, capture_output=True, check=False)
    dependency_snapshot = "\n".join(sorted(line.strip() for line in freeze.stdout.splitlines() if line.strip()))
    status = _git_value("status", "--porcelain=v1", "--untracked-files=all")
    return {
        "captured_at": datetime.now(UTC).isoformat(),
        "git_commit": _git_value("rev-parse", "HEAD"),
        "git_branch": _git_value("branch", "--show-current"),
        "git_dirty": bool(status and status != "UNAVAILABLE"),
        "git_status_sha256": _sha256_bytes(status.encode("utf-8")),
        "source_tree_root_sha256": _source_tree_root(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "dependency_snapshot_sha256": _sha256_bytes(dependency_snapshot.encode("utf-8")),
        "dependency_snapshot_count": len(dependency_snapshot.splitlines()) if dependency_snapshot else 0,
        "test_profile": "local-deterministic-no-external-hardware-or-credentials",
    }


def _junit_counts(path: Path) -> tuple[int, int, int, int]:
    if not path.exists():
        return 0, 0, 0, 0
    root = ET.parse(path).getroot()
    suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))

    def total(key: str) -> int:
        return sum(int(float(item.attrib.get(key, "0"))) for item in suites)

    return total("tests"), total("failures"), total("errors"), total("skipped")


def _terminate_process_group(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=5)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)


def _suite(name: str, paths: Sequence[str], *, timeout_seconds: int) -> SuiteResult:
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    junit = REPORT_ROOT / f"{name}.xml"
    log = REPORT_ROOT / f"{name}.log"
    staged_junit = REPORT_ROOT / f".{name}.next.xml"
    staged_log = REPORT_ROOT / f".{name}.next.log"
    staged_junit.unlink(missing_ok=True)
    staged_log.unlink(missing_ok=True)
    command = [sys.executable, "-m", "pytest", "-q", *paths, f"--junitxml={staged_junit}"]
    environment = dict(os.environ)
    environment.update({"PYTHONPATH": f"{ROOT / 'src'}:{ROOT}", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"})
    started = time.perf_counter()
    print(f"[test-matrix] starting {name}: {' '.join(command)}", flush=True)
    with staged_log.open("wb") as output:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=environment,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            exit_code = process.wait(timeout=timeout_seconds)
            status = "passed" if exit_code == 0 else "failed"
        except subprocess.TimeoutExpired:
            _terminate_process_group(process)
            exit_code = 124
            status = "timeout"
            output.write(f"\nTIMEOUT after {timeout_seconds}s\n".encode("utf-8"))
    elapsed = time.perf_counter() - started
    tests, failures, errors, skipped = _junit_counts(staged_junit)
    if staged_junit.is_file():
        staged_junit.replace(junit)
    if staged_log.is_file():
        staged_log.replace(log)
    print(
        f"[test-matrix] {name}: {status}; tests={tests}; failures={failures}; "
        f"errors={errors}; skipped={skipped}; elapsed={elapsed:.2f}s",
        flush=True,
    )
    return SuiteResult(
        name=name,
        command=command,
        status=status,
        exit_code=exit_code,
        elapsed_seconds=round(elapsed, 6),
        tests=tests,
        failures=failures,
        errors=errors,
        skipped=skipped,
        junit_path=str(junit.relative_to(ROOT)),
        log_path=str(log.relative_to(ROOT)),
        input_root_sha256=_hash_path_set(paths),
        junit_sha256=_sha256_file(junit),
        log_sha256=_sha256_file(log),
    )


def run(*, timeout_seconds: int = 180, jobs: int = 5) -> dict[str, object]:
    configured_suites = [
        ("contract", ["tests/contract"]),
        ("integration", ["tests/integration"]),
        ("migration", ["tests/migration"]),
        ("security", ["tests/security"]),
        ("unit", ["tests/unit"]),
        ("property", ["tests/property"]),
        ("privacy", ["tests/privacy"]),
        ("e2e", ["tests/e2e"]),
        ("acceptance", ["tests/acceptance"]),
        ("spec", ["tests/spec"]),
    ]
    suites = [
        (name, paths)
        for name, paths in configured_suites
        if any((ROOT / path).rglob("test_*.py") for path in paths)
    ]
    by_name: dict[str, SuiteResult] = {}
    with ThreadPoolExecutor(max_workers=max(1, min(jobs, len(suites)))) as executor:
        futures = {
            executor.submit(_suite, name, paths, timeout_seconds=timeout_seconds): name
            for name, paths in suites
        }
        for future in as_completed(futures):
            result = future.result()
            by_name[result.name] = result
    results = [by_name[name] for name, _ in suites]
    status = "passed" if all(result.status == "passed" for result in results) else "failed"
    payload: dict[str, object] = {
        "schema": "sip.test-matrix/v2",
        "evidence": _environment_evidence(),
        "verification_policy": {"required_exit_code": 0, "maximum_failures": 0, "maximum_errors": 0, "manual_reviewer": None},
        "status": status,
        "python": sys.version,
        "plugin_autoload_disabled": True,
        "suite_process_isolation": True,
        "suite_parallelism": max(1, min(jobs, len(suites))),
        "results": [asdict(result) for result in results],
        "totals": {
            "tests": sum(result.tests for result in results),
            "failures": sum(result.failures for result in results),
            "errors": sum(result.errors for result in results),
            "skipped": sum(result.skipped for result in results),
            "elapsed_seconds": round(sum(result.elapsed_seconds for result in results), 6),
        },
    }
    destination = ROOT / "build" / "reports" / "test-matrix.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description="Run SIP test categories in isolated pytest processes.")
    parser.add_argument("--timeout", type=int, default=180, help="per-suite timeout in seconds")
    parser.add_argument("--jobs", type=int, default=5, help="number of isolated suites to execute concurrently")
    args = parser.parse_args()
    result = run(timeout_seconds=args.timeout, jobs=args.jobs)
    print(json.dumps(result, indent=2, sort_keys=True))
    if result["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
