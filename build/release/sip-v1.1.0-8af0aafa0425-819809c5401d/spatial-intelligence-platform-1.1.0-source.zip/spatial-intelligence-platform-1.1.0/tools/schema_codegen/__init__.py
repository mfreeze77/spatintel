"""Versioned schema generation tools."""
