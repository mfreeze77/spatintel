from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from sip.spec_lint import run

ROOT = Path(__file__).resolve().parents[2]


def test_spec_lint_indexes_every_normative_requirement() -> None:
    """REQ: GOVDOC-001 every normative requirement remains uniquely indexed and source-addressable."""
    report = run(release=False)
    assert report["status"] == "passed", report["findings"][:20]
    assert report["spec_requirements"] == 1028
    assert report["ledger_requirements"] == 1028


def test_requirements_outputs_are_queryable_and_have_controlled_test_plans() -> None:
    """REQ: TSTTRACE-001 requirements traceability is machine-readable and queryable."""
    ledger = json.loads((ROOT / "requirements/requirements-ledger.json").read_text())
    assert len(ledger["documents"]) == 164
    assert len(ledger["requirements"]) == 1028
    plans = list((ROOT / "tests/spec/requirements").glob("*.yaml"))
    assert len(plans) == 1028
    with sqlite3.connect(ROOT / "requirements/requirements-ledger.sqlite") as connection:
        count = connection.execute("SELECT COUNT(*) FROM requirements").fetchone()[0]
        p0 = connection.execute("SELECT COUNT(*) FROM requirements WHERE priority='P0'").fetchone()[0]
    assert count == 1028
    assert p0 == 504


def test_release_spec_gate_fails_closed_on_unverified_requirements() -> None:
    """REQ: TSTGATE-001 production promotion is denied while mandatory requirements lack evidence."""
    report = run(release=True)
    assert report["status"] == "failed"
    assert any(item["code"] == "RELEASE_REQUIREMENT_INCOMPLETE" for item in report["findings"])
