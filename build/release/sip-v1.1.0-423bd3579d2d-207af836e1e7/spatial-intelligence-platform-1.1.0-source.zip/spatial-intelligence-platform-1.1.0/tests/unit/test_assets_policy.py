from __future__ import annotations

import pytest

from sip.canonical import sha256_bytes
from sip.errors import AuthorizationError, ValidationError
from sip.models import Audience, AuthorityClass, Classification, ProvenanceRef, SignedPrincipal, SourceClass


@pytest.mark.unit
def test_datasasset_001_content_addressed_encrypted_immutable_ingest(bootstrapped) -> None:
    """REQ-DATASSET-001, REQ-DATASSET-002: immutable hash identity and encrypted local bytes."""
    context, tenant_id, project_id, actor = bootstrapped
    payload = b"original immutable capture bytes"
    asset = context.assets.ingest_bytes(
        tenant_id=tenant_id,
        project_id=project_id,
        data=payload,
        media_type="application/octet-stream",
        original_name="capture.bin",
        classification=Classification.CONFIDENTIAL,
        retention_class="source_evidence",
        source_class=SourceClass.DIRECT_CAPTURE,
        authority_class=AuthorityClass.EVIDENCE,
        provenance=ProvenanceRef(source_ids=["fixture"], output_hash=sha256_bytes(payload)),
        actor_id=actor,
    )
    assert asset.sha256 == sha256_bytes(payload)
    assert context.store.path_for(asset.sha256).read_bytes() != payload
    assert context.assets.read(tenant_id, project_id, asset.asset_id, actor_id=actor) == payload


@pytest.mark.unit
@pytest.mark.security
def test_arciam_001_server_side_tenant_project_purpose_and_sensitive_policy(bootstrapped) -> None:
    """REQ-ARCIAM-001: client hiding is not authorization; tenant/project/purpose enforced server-side."""
    context, tenant_id, project_id, _ = bootstrapped
    principal = SignedPrincipal(
        subject_id="reviewer",
        tenant_id=tenant_id,
        project_ids=[project_id],
        roles=["reviewer"],
        purposes=["quality_review"],
        audience=Audience.PROJECT,
    )
    assert context.policy.require(
        principal,
        action="asset:read",
        tenant_id=tenant_id,
        project_id=project_id,
        purpose="quality_review",
        classification=Classification.INTERNAL.value,
    ).allowed
    with pytest.raises(AuthorizationError) as error:
        context.policy.require(
            principal,
            action="asset:read",
            tenant_id="another-tenant",
            project_id=project_id,
            purpose="quality_review",
        )
    assert error.value.code == "TENANT_MISMATCH"
    with pytest.raises(AuthorizationError):
        context.policy.require(
            principal,
            action="asset:read",
            tenant_id=tenant_id,
            project_id=project_id,
            purpose="marketing",
        )


@pytest.mark.unit
@pytest.mark.security
def test_opssec_signed_asset_token_is_scoped_and_temporary(bootstrapped) -> None:
    context, tenant_id, project_id, actor = bootstrapped
    payload = b"token fixture"
    asset = context.assets.ingest_bytes(
        tenant_id=tenant_id,
        project_id=project_id,
        data=payload,
        media_type="text/plain",
        original_name="token.txt",
        classification=Classification.INTERNAL,
        retention_class="project_record",
        source_class=SourceClass.DIRECT_CAPTURE,
        authority_class=AuthorityClass.EVIDENCE,
        provenance=ProvenanceRef(source_ids=["fixture"]),
        actor_id=actor,
    )
    token = context.assets.issue_read_token(tenant_id, project_id, asset.asset_id, subject_id="reviewer", ttl_seconds=60)
    assert context.assets.read_with_token(token) == payload
    with pytest.raises(ValidationError):
        context.assets.issue_read_token(tenant_id, project_id, asset.asset_id, subject_id="reviewer", ttl_seconds=7200)
