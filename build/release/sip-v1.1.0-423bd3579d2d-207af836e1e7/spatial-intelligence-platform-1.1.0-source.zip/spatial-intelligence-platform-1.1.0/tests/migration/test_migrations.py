from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
from pathlib import Path

import pytest

from sip.database import Base

ROOT = Path(__file__).parents[2]


def _alembic(database: Path, *args: str, extra_env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["alembic", "-c", "alembic.ini", *args],
        cwd=ROOT,
        env={
            **os.environ,
            "PYTHONPATH": "src",
            "SIP_DATABASE_URL": f"sqlite:///{database}",
            **(extra_env or {}),
        },
        text=True,
        capture_output=True,
        check=False,
    )


@pytest.mark.migration
def test_clean_install_reaches_head_and_matches_canonical_tables(tmp_path: Path) -> None:
    database = tmp_path / "clean.sqlite3"
    result = _alembic(database, "upgrade", "head")
    assert result.returncode == 0, result.stdout + result.stderr
    connection = sqlite3.connect(database)
    actual = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    expected = set(Base.metadata.tables)
    assert expected <= actual
    assert actual - expected == {"alembic_version"}
    assert connection.execute("SELECT version_num FROM alembic_version").fetchone()[0] == "0005_worker_candidate_idempotency"


@pytest.mark.migration
def test_upgrade_from_foundation_preserves_immutable_identifiers_and_hashes(tmp_path: Path) -> None:
    database = tmp_path / "upgrade.sqlite3"
    assert _alembic(database, "upgrade", "0001_foundation_control_plane").returncode == 0
    connection = sqlite3.connect(database)
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("INSERT INTO tenants(tenant_id,name,status,created_at) VALUES (?,?,?,CURRENT_TIMESTAMP)", ("tenant-upgrade", "Upgrade", "active"))
    connection.execute(
        "INSERT INTO projects(project_id,tenant_id,name,vertical,classification,status,created_at) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP)",
        ("project-upgrade", "tenant-upgrade", "Upgrade", "platform", "internal", "active"),
    )
    digest = "a" * 64
    connection.execute(
        "INSERT INTO assets(sha256,byte_count,media_type,storage_key,encryption_metadata,created_at) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)",
        (digest, 5, "application/octet-stream", digest, "{}"),
    )
    connection.execute(
        "INSERT INTO asset_refs(asset_id,tenant_id,project_id,sha256,original_name,classification,retention_class,source_class,authority_class,provenance_json,legal_hold,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
        ("asset-upgrade", "tenant-upgrade", "project-upgrade", digest, "source.bin", "internal", "preservation", "direct_capture", "evidence", "{}", 0, "fixture"),
    )
    connection.commit()
    connection.close()
    result = _alembic(database, "upgrade", "head")
    assert result.returncode == 0, result.stdout + result.stderr
    connection = sqlite3.connect(database)
    assert connection.execute("SELECT sha256 FROM asset_refs WHERE asset_id='asset-upgrade'").fetchone()[0] == digest
    assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


@pytest.mark.migration
def test_destructive_downgrade_is_denied_by_default_and_rehearsable_only_explicitly(tmp_path: Path) -> None:
    database = tmp_path / "downgrade.sqlite3"
    assert _alembic(database, "upgrade", "head").returncode == 0
    denied = _alembic(database, "downgrade", "-1")
    assert denied.returncode != 0
    assert "destructive downgrade denied" in denied.stderr
    rehearsed = _alembic(database, "downgrade", "base", extra_env={"SIP_ALLOW_DESTRUCTIVE_DOWNGRADE": "1"})
    assert rehearsed.returncode == 0, rehearsed.stdout + rehearsed.stderr


@pytest.mark.migration
def test_append_only_migration_manifest_matches_bytes() -> None:
    manifest = json.loads((ROOT / "migrations" / "manifest.json").read_text())
    assert manifest["append_only"] is True
    revisions = []
    for item in manifest["migrations"]:
        path = ROOT / item["path"]
        payload = path.read_bytes()
        assert len(payload) == item["byte_count"]
        assert hashlib.sha256(payload).hexdigest() == item["sha256"]
        revisions.append(path.stem.split("_", 1)[0])
    assert revisions == ["0001", "0002", "0003", "0004", "0005"]
