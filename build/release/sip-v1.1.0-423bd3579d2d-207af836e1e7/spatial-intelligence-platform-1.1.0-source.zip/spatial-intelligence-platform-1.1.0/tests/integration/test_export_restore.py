from __future__ import annotations

from pathlib import Path

import pytest

from sip.canonical import sha256_bytes
from sip.models import AuthorityClass, Classification, ProvenanceRef, SourceClass


@pytest.mark.integration
@pytest.mark.acceptance
def test_pltio_foundation_open_export_clean_import_preserves_hash_and_semantic_identity(bootstrapped, tmp_path: Path) -> None:
    context, tenant_id, project_id, actor = bootstrapped
    payload = b"open-preservation-source"
    asset = context.assets.ingest_bytes(
        tenant_id=tenant_id,
        project_id=project_id,
        data=payload,
        media_type="application/octet-stream",
        original_name="source.bin",
        classification=Classification.INTERNAL,
        retention_class="preservation",
        source_class=SourceClass.DIRECT_CAPTURE,
        authority_class=AuthorityClass.EVIDENCE,
        provenance=ProvenanceRef(source_ids=["fixture"], output_hash=sha256_bytes(payload)),
        actor_id=actor,
    )
    scene = context.scene.create_scene(tenant_id, project_id, name="Export room", actor_id=actor)
    package = context.preservation.export_project(tenant_id, project_id, tmp_path / "project.sip-preservation.zip", actor_id=actor)
    verified = context.preservation.verify_export(tmp_path / "project.sip-preservation.zip")
    assert verified["root_hash"] == package["root_hash"]
    restored = context.preservation.import_project(
        tmp_path / "project.sip-preservation.zip",
        new_tenant_id="tenant-restored",
        new_project_id="project-restored",
        actor_id="restore-operator",
    )
    assert restored["source_root_hash"] == package["root_hash"]
    restored_refs = []
    from sqlalchemy import select
    from sip.database import AssetRefRow
    with context.database.session() as session:
        restored_refs = list(session.scalars(select(AssetRefRow).where(AssetRefRow.project_id == "project-restored")))
    assert len(restored_refs) == 1
    assert restored_refs[0].sha256 == asset.sha256
    assert context.assets.read("tenant-restored", "project-restored", restored_refs[0].asset_id, actor_id="restore-operator") == payload
