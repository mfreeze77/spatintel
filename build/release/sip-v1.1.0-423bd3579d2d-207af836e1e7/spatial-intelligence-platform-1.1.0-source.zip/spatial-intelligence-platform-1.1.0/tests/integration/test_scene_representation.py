from __future__ import annotations

import pytest

from sip.errors import ConflictError, ValidationError
from sip.models import AuthorityClass, ProvenanceRef, RepresentationKind, SourceClass
from sip.scene import ProxyHit


@pytest.mark.integration
def test_datgit_datscene_stable_entities_commits_diff_and_rollback(bootstrapped) -> None:
    context, tenant_id, project_id, actor = bootstrapped
    scene = context.scene.create_scene(tenant_id, project_id, name="Room", actor_id=actor)
    entity_id = context.scene.create_entity(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        entity_type="room",
        name="Mechanical Room",
        attributes={"number": "M101"},
        source_class=SourceClass.OBSERVED,
        authority_class=AuthorityClass.EVIDENCE,
        confidence=1.0,
        provenance=ProvenanceRef(source_ids=["capture:fixture"]),
        policy={"audience": "project"},
        stable_support={"frame_id": "world", "point": [0, 0, 0]},
        actor_id=actor,
    )
    first = context.scene.commit(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        branch="main",
        expected_head=scene["commit_id"],
        message="Add room",
        actor_id=actor,
    )
    assert entity_id in context.scene.diff(scene["commit_id"], first["commit_id"])["entities"]["added"]
    rolled = context.scene.rollback_branch(tenant_id, project_id, scene["scene_id"], "main", scene["commit_id"], actor_id=actor)
    assert rolled["snapshot_hash"]
    with pytest.raises(ValidationError):
        context.scene.create_entity(
            tenant_id=tenant_id,
            project_id=project_id,
            scene_id=scene["scene_id"],
            entity_type="object",
            name="Bad anchor",
            attributes={},
            source_class=SourceClass.OBSERVED,
            authority_class=AuthorityClass.EVIDENCE,
            confidence=1,
            provenance=ProvenanceRef(source_ids=["fixture"]),
            policy={},
            stable_support={"triangle_id": 5},
            actor_id=actor,
        )


@pytest.mark.integration
@pytest.mark.security
def test_hybrid_provider_quarantine_quality_publisher_and_proxy_measurement_guard(bootstrapped) -> None:
    context, tenant_id, project_id, actor = bootstrapped
    for provider_id in ("local-tsdf", "local-baseline"):
        context.providers.register(
            {
                "provider_id": provider_id,
                "version": "1.1.0",
                "source_url": f"local://sip/{provider_id}",
                "source_revision": "deterministic-reference",
                "license_id": "Apache-2.0",
                "approval_state": "approved",
                "allowed_classifications": ["internal"],
                "allowed_purposes": ["hybrid_fixture"],
                "allowed_regions": ["local"],
            },
            actor_id=actor,
        )
    scene = context.scene.create_scene(tenant_id, project_id, name="Hybrid room", actor_id=actor)
    metric = context.representations.create_candidate(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        asset_id="asset-metric",
        kind=RepresentationKind.METRIC,
        provider_id="local-tsdf",
        coordinate_frame_id="world",
        source_class=SourceClass.MEASURED,
        authority_class=AuthorityClass.METRIC,
        lossy=False,
        intended_uses=["measurement", "render"],
        prohibited_uses=[],
        quality={"rmse_m": 0.005},
        provenance={"source_ids": ["capture"]},
        support_map={},
        actor_id=actor,
    )
    context.representations.review_quality(metric, reviewer_id="geometry-reviewer", approved_uses=["measurement", "render"], metrics={"rmse_m": 0.005}, passed=True)
    context.publisher.publish(metric, commit_id=scene["commit_id"], role="measurement", publisher_id="publisher")
    proxy = context.representations.create_candidate(
        tenant_id=tenant_id,
        project_id=project_id,
        scene_id=scene["scene_id"],
        asset_id="asset-proxy",
        kind=RepresentationKind.INTERACTION,
        provider_id="local-baseline",
        coordinate_frame_id="world",
        source_class=SourceClass.GENERATED,
        authority_class=AuthorityClass.INTERACTION,
        lossy=True,
        intended_uses=["picking", "collision", "navigation"],
        prohibited_uses=["verified_measurement"],
        quality={"collision_coverage": 1.0},
        provenance={"source_ids": [metric]},
        support_map={"metric_representation_id": metric, "max_reprojection_error_m": 0.01, "anchors": []},
        actor_id=actor,
    )
    with pytest.raises(ConflictError):
        context.publisher.publish(proxy, commit_id=scene["commit_id"], role="picking", publisher_id="publisher")
    context.representations.review_quality(proxy, reviewer_id="interaction-reviewer", approved_uses=["picking", "collision"], metrics={"raycast_p95_ms": 2}, passed=True)
    context.publisher.publish(proxy, commit_id=scene["commit_id"], role="picking", publisher_id="publisher")
    resolved = context.scene.resolve_proxy_hit(
        tenant_id,
        project_id,
        ProxyHit(representation_id=proxy, world_point=[1, 1, 1], normal=[0, 1, 0], support_hint={}),
    )
    assert resolved["authoritative_measurement_allowed"] is True
    with pytest.raises(ValidationError) as error:
        context.scene.create_measurement(
            tenant_id=tenant_id,
            project_id=project_id,
            scene_id=scene["scene_id"],
            entity_id=None,
            value=1.0,
            unit="m",
            uncertainty=0.01,
            source_asset_ids=["source"],
            calibration={"method": "fixture"},
            verifier_id="verifier",
            verified=True,
            actor_id=actor,
            originating_representation_id=proxy,
        )
    assert error.value.code == "NON_AUTHORITATIVE_MEASUREMENT_SOURCE"
