from __future__ import annotations

import argparse
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from .capture import CapturePackage
from .spec_lint import run as run_spec_lint

ROOT = Path(__file__).resolve().parents[2]


def _version(command: list[str]) -> str | None:
    if shutil.which(command[0]) is None:
        return None
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
        return (result.stdout or result.stderr).strip().splitlines()[0]
    except Exception:
        return "present-but-version-query-failed"


def doctor() -> dict[str, Any]:
    tools = {
        "python": platform.python_version(),
        "git": _version(["git", "--version"]),
        "node": _version(["node", "--version"]),
        "npm": _version(["npm", "--version"]),
        "pnpm": _version(["pnpm", "--version"]),
        "swift": _version(["swift", "--version"]),
        "docker": _version(["docker", "--version"]),
        "terraform": _version(["terraform", "version"]),
        "kubectl": _version(["kubectl", "version", "--client"]),
        "just": _version(["just", "--version"]),
    }
    required_local = ["python", "git"]
    return {
        "status": "healthy" if all(tools[name] for name in required_local) else "missing-required-tool",
        "platform": platform.platform(),
        "tools": tools,
        "profiles": {
            "cpu_reference": tools["python"] is not None,
            "web": tools["node"] is not None and tools["npm"] is not None,
            "swift_fixture": tools["swift"] is not None,
            "containers": tools["docker"] is not None,
            "terraform": tools["terraform"] is not None,
            "kubernetes": tools["kubectl"] is not None,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(prog="sip", description="Spatial Intelligence Platform developer and operator CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    spec = sub.add_parser("spec-check")
    spec.add_argument("--release", action="store_true")
    capture = sub.add_parser("validate-capture")
    capture.add_argument("path", type=Path)
    args = parser.parse_args()

    if args.command == "doctor":
        result = doctor()
    elif args.command == "spec-check":
        result = run_spec_lint(release=args.release)
    elif args.command == "validate-capture":
        result = CapturePackage.validate(args.path)
    else:
        parser.error("unknown command")
        return
    print(json.dumps(result, indent=2, sort_keys=True, default=str))
    if result.get("status") == "failed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
