from __future__ import annotations

import math
import re
from datetime import datetime
from typing import Any

from sqlalchemy import select

from .canonical import canonical_sha256, new_uuid
from .database import Database, SearchDocumentRow
from .errors import ValidationError


class SearchService:
    def __init__(self, database: Database) -> None:
        self.database = database

    def index(
        self,
        *,
        tenant_id: str,
        project_id: str,
        text: str,
        entity_id: str | None,
        asset_id: str | None,
        embedding: list[float] | None,
        spatial_bounds: dict[str, Any] | None,
        temporal_start: datetime | None,
        temporal_end: datetime | None,
        policy: dict[str, Any],
    ) -> str:
        if temporal_start and temporal_end and temporal_end < temporal_start:
            raise ValidationError("SEARCH_TEMPORAL_RANGE", "temporal end precedes start")
        terms = sorted(set(re.findall(r"[a-z0-9]+", text.lower())))
        document_id = new_uuid()
        source_hash = canonical_sha256(
            {
                "text": text,
                "entity_id": entity_id,
                "asset_id": asset_id,
                "embedding": embedding,
                "spatial_bounds": spatial_bounds,
                "temporal_start": temporal_start.isoformat() if temporal_start else None,
                "temporal_end": temporal_end.isoformat() if temporal_end else None,
            }
        )
        with self.database.session() as session:
            session.add(
                SearchDocumentRow(
                    document_id=document_id,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    entity_id=entity_id,
                    asset_id=asset_id,
                    text=text,
                    terms_json=terms,
                    embedding_json=embedding,
                    spatial_bounds_json=spatial_bounds,
                    temporal_start=temporal_start,
                    temporal_end=temporal_end,
                    policy_json=policy,
                    source_hash=source_hash,
                )
            )
        return document_id

    def query(
        self,
        *,
        tenant_id: str,
        project_id: str,
        text: str | None = None,
        embedding: list[float] | None = None,
        point: list[float] | None = None,
        at_time: datetime | None = None,
        allowed_audiences: set[str] | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        if limit < 1 or limit > 500:
            raise ValidationError("SEARCH_LIMIT", "search limit must be between 1 and 500")
        with self.database.session() as session:
            rows = list(session.scalars(select(SearchDocumentRow).where(SearchDocumentRow.tenant_id == tenant_id, SearchDocumentRow.project_id == project_id)))
        terms = set(re.findall(r"[a-z0-9]+", (text or "").lower()))
        results: list[tuple[float, SearchDocumentRow]] = []
        for row in rows:
            audience = row.policy_json.get("audience", "private")
            if allowed_audiences is not None and audience not in allowed_audiences:
                continue
            if at_time and ((row.temporal_start and at_time < row.temporal_start) or (row.temporal_end and at_time > row.temporal_end)):
                continue
            if point and row.spatial_bounds_json and not _contains(row.spatial_bounds_json, point):
                continue
            lexical = len(terms & set(row.terms_json)) / max(len(terms), 1) if terms else 0.0
            vector = _cosine(embedding, row.embedding_json) if embedding and row.embedding_json else 0.0
            spatial = 1.0 if point and row.spatial_bounds_json else 0.0
            score = lexical * 0.5 + vector * 0.4 + spatial * 0.1
            if not terms and not embedding and not point:
                score = 1.0
            if score > 0:
                results.append((score, row))
        return [
            {
                "document_id": row.document_id,
                "entity_id": row.entity_id,
                "asset_id": row.asset_id,
                "text": row.text,
                "score": score,
                "source_hash": row.source_hash,
                "policy": row.policy_json,
            }
            for score, row in sorted(results, key=lambda item: (-item[0], item[1].document_id))[:limit]
        ]


def _cosine(left: list[float], right: list[float]) -> float:
    if len(left) != len(right) or not left:
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=True))
    a_norm = math.sqrt(sum(a * a for a in left))
    b_norm = math.sqrt(sum(b * b for b in right))
    return dot / (a_norm * b_norm) if a_norm and b_norm else 0.0


def _contains(bounds: dict[str, Any], point: list[float]) -> bool:
    minimum, maximum = bounds.get("min"), bounds.get("max")
    return bool(minimum and maximum and len(point) == 3 and all(float(minimum[i]) <= float(point[i]) <= float(maximum[i]) for i in range(3)))
