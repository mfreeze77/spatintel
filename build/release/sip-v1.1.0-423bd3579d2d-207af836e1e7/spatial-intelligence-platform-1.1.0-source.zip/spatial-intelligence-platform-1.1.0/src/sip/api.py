from __future__ import annotations
import base64
import os
from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, Literal
from fastapi import APIRouter, Depends, FastAPI, Header, Query, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from .auth import authenticate_request
from .canonical import new_uuid, sha256_bytes
from .config import Settings
from .context import PlatformContext
from .errors import AuthenticationError, AuthorizationError, ConflictError, NotFoundError, SIPError, ValidationError
from .models import Audience, AuthorityClass, Classification, ProvenanceRef, RepresentationKind, SignedPrincipal, SourceClass
from .observability import (
    BoundTelemetryContext,
    PlatformObservability,
    RequestTimer,
    bind_telemetry_context,
    configure_logging,
    configure_tracing,
    current_trace_id,
    pseudonymize_identifier,
    server_span,
)
from .scene import ProxyHit
API_VERSION = '1.1.0'
Principal = Annotated[SignedPrincipal, Depends(authenticate_request)]

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

class TenantCreate(StrictModel):
    name: str = Field(min_length=1, max_length=256)
    tenant_id: str | None = None

class ProjectCreate(StrictModel):
    name: str = Field(min_length=1, max_length=256)
    vertical: Literal['platform', 'construction', 'liveforever'] = 'platform'
    classification: Classification = Classification.INTERNAL
    project_id: str | None = None

class IdentityCreate(StrictModel):
    identity_id: str
    display_name: str
    identity_type: Literal['user', 'service'] = 'user'

class RoleBind(StrictModel):
    binding_id: str | None = None
    project_id: str | None = None
    identity_id: str
    role: str
    purposes: list[str] = Field(min_length=1)
    spatial_restrictions: list[dict[str, Any]] = []
    expires_at: datetime | None = None

class PolicyEvaluate(StrictModel):
    action: str
    tenant_id: str
    project_id: str | None = None
    purpose: str | None = None
    classification: Classification = Classification.INTERNAL
    required_audience: Audience | None = None
    spatial_region_id: str | None = None

class AssetIngest(StrictModel):
    content_base64: str
    media_type: str
    original_name: str
    classification: Classification = Classification.INTERNAL
    retention_class: str = 'standard'
    source_class: SourceClass = SourceClass.DIRECT_CAPTURE
    authority_class: AuthorityClass = AuthorityClass.EVIDENCE
    provenance: ProvenanceRef

class MultipartBegin(StrictModel):
    expected_sha256: str = Field(pattern='^[a-f0-9]{64}$')
    expected_bytes: int = Field(ge=0)
    media_type: str
    metadata: dict[str, Any] = {}

class MultipartPart(StrictModel):
    content_base64: str
    expected_sha256: str = Field(pattern='^[a-f0-9]{64}$')

class MultipartComplete(StrictModel):
    original_name: str
    classification: Classification
    retention_class: str
    source_class: SourceClass
    authority_class: AuthorityClass
    provenance: ProvenanceRef

class OperationCreate(StrictModel):
    operation_type: str
    idempotency_key: str
    input_manifest: dict[str, Any]
    max_attempts: int = Field(default=3, ge=1, le=20)

class WorkerLease(StrictModel):
    worker_id: str
    lease_seconds: int = Field(default=60, ge=10, le=3600)

class WorkerCheckpoint(StrictModel):
    worker_id: str
    progress: float = Field(ge=0, le=1)
    checkpoint: dict[str, Any]

class WorkerComplete(StrictModel):
    worker_id: str
    output: dict[str, Any]

class WorkerFail(StrictModel):
    worker_id: str
    code: str
    message: str
    retryable: bool = True

class SceneCreate(StrictModel):
    name: str

class EntityCreate(StrictModel):
    entity_type: str
    name: str
    attributes: dict[str, Any] = {}
    source_class: SourceClass
    authority_class: AuthorityClass
    confidence: float = Field(ge=0, le=1)
    provenance: ProvenanceRef
    policy: dict[str, Any] = {}
    stable_support: dict[str, Any] = {}
    entity_id: str | None = None

class CommitCreate(StrictModel):
    branch: str = 'main'
    expected_head: str | None = None
    message: str

class BranchCreate(StrictModel):
    name: str
    from_commit_id: str
    protected: bool = False

class RollbackRequest(StrictModel):
    target_commit_id: str

class MeasurementCreate(StrictModel):
    entity_id: str
    value: float
    unit: str
    uncertainty: float = Field(ge=0)
    source_asset_ids: list[str] = Field(min_length=1)
    calibration: dict[str, Any]
    verifier_id: str | None = None
    verified: bool = False
    originating_representation_id: str | None = None

class ProxyResolve(StrictModel):
    representation_id: str
    point: list[float] = Field(min_length=3, max_length=3)
    semantic_entity_id: str | None = None
    tolerance_m: float = Field(default=0.05, gt=0, le=5)

class ProviderRegister(StrictModel):
    manifest: dict[str, Any]

class ProviderAuthorize(StrictModel):
    classification: Classification
    purpose: str
    region: str
    external: bool = False

class RepresentationCreate(StrictModel):
    scene_id: str
    asset_id: str
    kind: RepresentationKind
    provider_id: str
    coordinate_frame_id: str
    source_class: SourceClass
    authority_class: AuthorityClass
    lossy: bool
    intended_uses: list[str]
    prohibited_uses: list[str] = []
    quality: dict[str, Any] = {}
    provenance: dict[str, Any]
    support_map: dict[str, Any] = {}

class RepresentationReview(StrictModel):
    approved_uses: list[str]
    metrics: dict[str, Any]
    passed: bool

class RepresentationPublish(StrictModel):
    commit_id: str
    role: str

class SearchIndex(StrictModel):
    text: str
    entity_id: str | None = None
    asset_id: str | None = None
    embedding: list[float] | None = None
    spatial_bounds: dict[str, Any] | None = None
    temporal_start: datetime | None = None
    temporal_end: datetime | None = None
    policy: dict[str, Any] = {}

class SearchQuery(StrictModel):
    text: str | None = None
    embedding: list[float] | None = None
    point: list[float] | None = None
    at_time: datetime | None = None
    allowed_audiences: list[Audience] = [Audience.PRIVATE]
    limit: int = Field(default=20, ge=1, le=200)

class ConstructionHierarchy(StrictModel):
    record_type: str
    name: str
    parent_id: str | None = None
    state: str = 'observed'
    attributes: dict[str, Any] = {}

class ConstructionSystem(StrictModel):
    system_type: str
    parent_id: str | None = None
    entity_id: str | None = None
    state: str
    data: dict[str, Any]
    evidence_asset_ids: list[str] = []

class ConstructionDocument(StrictModel):
    document_type: str
    asset_id: str
    parent_id: str | None = None
    page_region: dict[str, Any] | None = None
    spatial_anchor: dict[str, Any] | None = None
    data: dict[str, Any] = {}

class DeficiencyCreate(StrictModel):
    entity_id: str
    description: str
    severity: str
    evidence_asset_ids: list[str] = []

class DeficiencyRetest(StrictModel):
    correction: str
    correction_asset_ids: list[str]
    test_result: Literal['pass', 'fail']
    test_asset_ids: list[str]

class ConsentGrantCreate(StrictModel):
    subject_id: str
    purposes: list[str] = Field(min_length=1)
    audiences: list[Audience] = Field(min_length=1)
    scopes: list[str] = Field(min_length=1)
    derivative_policy: dict[str, Any]
    expires_at: datetime | None = None

class ConsentRevoke(StrictModel):
    reason: str

class MemoryCreate(StrictModel):
    record_type: str
    subject_id: str
    related_ids: list[str] = []
    data: dict[str, Any]
    source_class: SourceClass
    confidence: float = Field(ge=0, le=1)
    evidence_asset_ids: list[str] = []
    audience: Audience
    purpose: str
    generated_lineage: dict[str, Any] | None = None

class ConflictingRecollections(StrictModel):
    subject_id: str
    event_key: str
    recollections: list[dict[str, Any]] = Field(min_length=2)
    audience: Audience

class ExperienceRequest(StrictModel):
    subject_id: str
    requested_features: dict[str, bool]
    audience: Audience

class NotificationCreate(StrictModel):
    recipient_id: str
    channel: Literal['in_app', 'email', 'sms', 'push']
    template_id: str
    payload: dict[str, Any]
    sensitive: bool = False

class CommentCreate(StrictModel):
    body: str
    scene_commit_id: str | None = None
    entity_id: str | None = None
    anchor: dict[str, Any] | None = None
    supersedes_comment_id: str | None = None

class TaskCreate(StrictModel):
    title: str
    description: str
    entity_id: str | None = None
    assignee_id: str | None = None
    priority: str = 'normal'
    due_at: datetime | None = None

class TaskTransition(StrictModel):
    state: str

class ModelRegister(StrictModel):
    manifest: dict[str, Any]

class ModelAuthorize(StrictModel):
    checkpoint_hash: str
    purpose: str
    commercial: bool
    classification: Classification

def _context(request: Request) -> PlatformContext:
    return request.app.state.platform

def _require(request: Request, principal: SignedPrincipal, *, action: str, tenant_id: str, project_id: str | None=None, purpose: str | None=None, classification: Classification | str=Classification.INTERNAL, audience: Audience | None=None) -> None:
    value = classification.value if isinstance(classification, Classification) else classification
    _context(request).policy.require(principal, action=action, tenant_id=tenant_id, project_id=project_id, purpose=purpose, classification=value, required_audience=audience)

def _json(value: Any) -> Any:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, BaseModel):
        return value.model_dump(mode='json')
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {key: _json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json(item) for item in value]
    return value

def _routers() -> dict[str, APIRouter]:
    control = APIRouter(tags=['control'])
    identity = APIRouter(tags=['identity-policy'])
    capture = APIRouter(tags=['capture'])
    workflow = APIRouter(tags=['workflow'])
    scene = APIRouter(tags=['scene'])
    evidence = APIRouter(tags=['evidence'])
    search = APIRouter(tags=['search'])
    export = APIRouter(tags=['export'])
    notification = APIRouter(tags=['notification'])
    audit = APIRouter(tags=['audit'])
    representation = APIRouter(tags=['representation'])
    providers = APIRouter(tags=['provider-registry'])
    publisher = APIRouter(tags=['representation-publisher'])
    construction = APIRouter(tags=['construction'])
    memory = APIRouter(tags=['liveforever'])
    collaboration = APIRouter(tags=['collaboration'])

    @control.get('/version', operation_id='get_version')
    def version(request: Request) -> dict[str, Any]:
        return {'version': API_VERSION, 'environment': _context(request).settings.environment}

    @control.post('/v1/tenants', status_code=201, operation_id='create_tenant')
    def create_tenant(body: TenantCreate, request: Request, principal: Principal) -> dict[str, Any]:
        if 'bootstrap_admin' not in principal.roles and 'tenant_admin' not in principal.roles:
            raise AuthorizationError('TENANT_CREATE_DENIED', 'tenant creation requires bootstrap administration')
        tenant_id = _context(request).tenancy.create_tenant(body.name, tenant_id=body.tenant_id, actor_id=principal.subject_id)
        return {'tenant_id': tenant_id}

    @control.post('/v1/tenants/{tenant_id}/projects', status_code=201, operation_id='create_project')
    def create_project(tenant_id: str, body: ProjectCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:create', tenant_id=tenant_id)
        project_id = _context(request).tenancy.create_project(tenant_id, body.name, vertical=body.vertical, classification=body.classification.value, project_id=body.project_id, actor_id=principal.subject_id)
        return {'project_id': project_id}

    @identity.post('/v1/tenants/{tenant_id}/identities', status_code=201, operation_id='create_identity')
    def create_identity(tenant_id: str, body: IdentityCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:admin', tenant_id=tenant_id)
        _context(request).policy.create_identity(tenant_id, body.identity_id, body.display_name, body.identity_type)
        return {'identity_id': body.identity_id}

    @identity.post('/v1/tenants/{tenant_id}/role-bindings', status_code=201, operation_id='bind_role')
    def bind_role(tenant_id: str, body: RoleBind, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:admin', tenant_id=tenant_id, project_id=body.project_id)
        binding_id = body.binding_id or new_uuid()
        _context(request).policy.bind_role(binding_id=binding_id, tenant_id=tenant_id, project_id=body.project_id, identity_id=body.identity_id, role=body.role, purposes=body.purposes, spatial_restrictions=body.spatial_restrictions, expires_at=body.expires_at)
        return {'binding_id': binding_id}

    @identity.post('/v1/policy/evaluate', operation_id='evaluate_policy')
    def evaluate_policy(body: PolicyEvaluate, request: Request, principal: Principal) -> dict[str, Any]:
        decision = _context(request).policy.authorize(principal, action=body.action, tenant_id=body.tenant_id, project_id=body.project_id, purpose=body.purpose, classification=body.classification.value, required_audience=body.required_audience, spatial_region_id=body.spatial_region_id)
        return _json(decision)

    @capture.post('/v1/projects/{project_id}/assets', status_code=201, operation_id='ingest_asset')
    def ingest_asset(project_id: str, body: AssetIngest, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='asset:create', tenant_id=principal.tenant_id, project_id=project_id, classification=body.classification)
        try:
            payload = base64.b64decode(body.content_base64, validate=True)
        except Exception as exc:
            raise ValidationError('ASSET_BASE64_INVALID', 'asset content is not valid base64') from exc
        result = _context(request).assets.ingest_bytes(tenant_id=principal.tenant_id, project_id=project_id, data=payload, media_type=body.media_type, original_name=body.original_name, classification=body.classification, retention_class=body.retention_class, source_class=body.source_class, authority_class=body.authority_class, provenance=body.provenance, actor_id=principal.subject_id)
        return _json(result)

    @capture.get('/v1/projects/{project_id}/assets/{asset_id}', operation_id='get_asset')
    def get_asset(project_id: str, asset_id: str, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='asset:read', tenant_id=principal.tenant_id, project_id=project_id)
        return _json(_context(request).assets.get(principal.tenant_id, project_id, asset_id))

    @capture.get('/v1/projects/{project_id}/assets/{asset_id}/content', operation_id='read_asset')
    def read_asset(project_id: str, asset_id: str, request: Request, principal: Principal) -> Response:
        _require(request, principal, action='asset:read', tenant_id=principal.tenant_id, project_id=project_id)
        ref = _context(request).assets.get(principal.tenant_id, project_id, asset_id)
        payload = _context(request).assets.read(principal.tenant_id, project_id, asset_id, actor_id=principal.subject_id)
        return Response(content=payload, media_type=ref.media_type, headers={'Digest': f'sha-256={ref.sha256}'})

    @capture.post('/v1/projects/{project_id}/assets/{asset_id}/read-token', operation_id='issue_asset_read_token')
    def issue_asset_token(project_id: str, asset_id: str, request: Request, principal: Principal, ttl_seconds: int=Query(default=300, ge=1, le=3600)) -> dict[str, Any]:
        _require(request, principal, action='asset:read', tenant_id=principal.tenant_id, project_id=project_id)
        token = _context(request).assets.issue_read_token(principal.tenant_id, project_id, asset_id, subject_id=principal.subject_id, ttl_seconds=ttl_seconds)
        return {'token': token, 'expires_in_seconds': ttl_seconds}

    @capture.post('/v1/projects/{project_id}/multipart', status_code=201, operation_id='begin_multipart')
    def begin_multipart(project_id: str, body: MultipartBegin, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='asset:create', tenant_id=principal.tenant_id, project_id=project_id)
        upload_id = _context(request).assets.begin_multipart(tenant_id=principal.tenant_id, project_id=project_id, expected_sha256=body.expected_sha256, expected_bytes=body.expected_bytes, media_type=body.media_type, metadata=body.metadata, actor_id=principal.subject_id)
        return {'upload_id': upload_id}

    @capture.put('/v1/multipart/{upload_id}/parts/{part_number}', operation_id='put_multipart_part')
    def put_multipart_part(upload_id: str, part_number: int, body: MultipartPart, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='asset:create', tenant_id=principal.tenant_id)
        try:
            payload = base64.b64decode(body.content_base64, validate=True)
        except Exception as exc:
            raise ValidationError('CHUNK_BASE64_INVALID', 'chunk content is not valid base64') from exc
        return _context(request).assets.put_part(upload_id, part_number, payload, body.expected_sha256)

    @capture.post('/v1/multipart/{upload_id}/complete', operation_id='complete_multipart')
    def complete_multipart(upload_id: str, body: MultipartComplete, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='asset:create', tenant_id=principal.tenant_id)
        result = _context(request).assets.complete_multipart(upload_id, original_name=body.original_name, classification=body.classification, retention_class=body.retention_class, source_class=body.source_class, authority_class=body.authority_class, provenance=body.provenance, actor_id=principal.subject_id)
        return _json(result)

    @workflow.post('/v1/projects/{project_id}/operations', status_code=202, operation_id='create_operation')
    def create_operation(project_id: str, body: OperationCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:*', tenant_id=principal.tenant_id, project_id=project_id)
        return _context(request).operations.create(tenant_id=principal.tenant_id, project_id=project_id, operation_type=body.operation_type, idempotency_key=body.idempotency_key, input_manifest=body.input_manifest, actor_id=principal.subject_id, max_attempts=body.max_attempts)

    @workflow.get('/v1/operations/{operation_id}', operation_id='get_operation')
    def get_operation(operation_id: str, request: Request, principal: Principal) -> dict[str, Any]:
        result = _context(request).operations.get(operation_id)
        _require(request, principal, action='project:*', tenant_id=result['tenant_id'], project_id=result['project_id'])
        return result

    @workflow.post('/v1/operations/{operation_id}/cancel', status_code=202, operation_id='cancel_operation')
    def cancel_operation(operation_id: str, request: Request, principal: Principal) -> dict[str, Any]:
        result = _context(request).operations.get(operation_id)
        _require(request, principal, action='project:*', tenant_id=result['tenant_id'], project_id=result['project_id'])
        return _context(request).operations.request_cancel(operation_id, actor_id=principal.subject_id)

    @workflow.post('/v1/internal/operations/{operation_id}/lease', operation_id='lease_operation')
    def lease_operation(operation_id: str, body: WorkerLease, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='operation:lease', tenant_id=principal.tenant_id)
        return _context(request).operations.lease(operation_id, worker_id=body.worker_id, lease_seconds=body.lease_seconds)

    @workflow.post('/v1/internal/operations/{operation_id}/start', operation_id='start_operation')
    def start_operation(operation_id: str, body: WorkerLease, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='operation:lease', tenant_id=principal.tenant_id)
        return _context(request).operations.start(operation_id, worker_id=body.worker_id)

    @workflow.post('/v1/internal/operations/{operation_id}/checkpoint', operation_id='checkpoint_operation')
    def checkpoint_operation(operation_id: str, body: WorkerCheckpoint, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='operation:checkpoint', tenant_id=principal.tenant_id)
        return _context(request).operations.checkpoint(operation_id, worker_id=body.worker_id, progress=body.progress, checkpoint=body.checkpoint)

    @workflow.post('/v1/internal/operations/{operation_id}/complete', operation_id='complete_operation')
    def complete_operation(operation_id: str, body: WorkerComplete, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='operation:complete', tenant_id=principal.tenant_id)
        return _context(request).operations.complete(operation_id, worker_id=body.worker_id, output=body.output)

    @workflow.post('/v1/internal/operations/{operation_id}/fail', operation_id='fail_operation')
    def fail_operation(operation_id: str, body: WorkerFail, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='operation:complete', tenant_id=principal.tenant_id)
        return _context(request).operations.fail(operation_id, worker_id=body.worker_id, code=body.code, message=body.message, retryable=body.retryable)

    @scene.post('/v1/projects/{project_id}/scenes', status_code=201, operation_id='create_scene')
    def create_scene(project_id: str, body: SceneCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:commit', tenant_id=principal.tenant_id, project_id=project_id)
        return _context(request).scene.create_scene(principal.tenant_id, project_id, name=body.name, actor_id=principal.subject_id)

    @scene.post('/v1/projects/{project_id}/scenes/{scene_id}/entities', status_code=201, operation_id='create_scene_entity')
    def create_entity(project_id: str, scene_id: str, body: EntityCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:commit', tenant_id=principal.tenant_id, project_id=project_id)
        entity_id = _context(request).scene.create_entity(tenant_id=principal.tenant_id, project_id=project_id, scene_id=scene_id, entity_type=body.entity_type, name=body.name, attributes=body.attributes, source_class=body.source_class, authority_class=body.authority_class, confidence=body.confidence, provenance=body.provenance, policy=body.policy, stable_support=body.stable_support, actor_id=principal.subject_id, entity_id=body.entity_id)
        return {'entity_id': entity_id}

    @scene.post('/v1/projects/{project_id}/scenes/{scene_id}/commits', status_code=201, operation_id='commit_scene')
    def commit_scene(project_id: str, scene_id: str, body: CommitCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:commit', tenant_id=principal.tenant_id, project_id=project_id)
        return _context(request).scene.commit(tenant_id=principal.tenant_id, project_id=project_id, scene_id=scene_id, branch=body.branch, expected_head=body.expected_head, message=body.message, actor_id=principal.subject_id)

    @scene.post('/v1/projects/{project_id}/scenes/{scene_id}/branches', status_code=201, operation_id='create_scene_branch')
    def create_branch(project_id: str, scene_id: str, body: BranchCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:commit', tenant_id=principal.tenant_id, project_id=project_id)
        branch_id = _context(request).scene.create_branch(principal.tenant_id, project_id, scene_id, name=body.name, from_commit_id=body.from_commit_id, protected=body.protected)
        return {'branch_id': branch_id}

    @scene.get('/v1/scene-diffs', operation_id='diff_scene_commits')
    def diff_scene(left: str, right: str, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:read', tenant_id=principal.tenant_id)
        return _context(request).scene.diff(left, right)

    @scene.post('/v1/projects/{project_id}/scenes/{scene_id}/branches/{branch}/rollback', operation_id='rollback_scene_branch')
    def rollback(project_id: str, scene_id: str, branch: str, body: RollbackRequest, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:commit', tenant_id=principal.tenant_id, project_id=project_id)
        return _context(request).scene.rollback_branch(principal.tenant_id, project_id, scene_id, branch, body.target_commit_id, actor_id=principal.subject_id)

    @scene.post('/v1/projects/{project_id}/scenes/{scene_id}/measurements', status_code=201, operation_id='create_measurement')
    def create_measurement(project_id: str, scene_id: str, body: MeasurementCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:review' if body.verified else 'scene:commit', tenant_id=principal.tenant_id, project_id=project_id)
        measurement_id = _context(request).scene.create_measurement(tenant_id=principal.tenant_id, project_id=project_id, scene_id=scene_id, entity_id=body.entity_id, value=body.value, unit=body.unit, uncertainty=body.uncertainty, source_asset_ids=body.source_asset_ids, calibration=body.calibration, verifier_id=body.verifier_id, verified=body.verified, actor_id=principal.subject_id, originating_representation_id=body.originating_representation_id)
        return {'measurement_id': measurement_id}

    @scene.post('/v1/projects/{project_id}/proxy-hits/resolve', operation_id='resolve_proxy_hit')
    def resolve_proxy_hit(project_id: str, body: ProxyResolve, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:read', tenant_id=principal.tenant_id, project_id=project_id)
        hit = ProxyHit(representation_id=body.representation_id, point=body.point, semantic_entity_id=body.semantic_entity_id)
        return _context(request).scene.resolve_proxy_hit(principal.tenant_id, project_id, hit, tolerance_m=body.tolerance_m)

    @providers.post('/v1/providers', status_code=201, operation_id='register_provider')
    def register_provider(body: ProviderRegister, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:admin', tenant_id=principal.tenant_id)
        return _context(request).providers.register(body.manifest, actor_id=principal.subject_id)

    @providers.post('/v1/providers/{provider_id}/authorize', operation_id='authorize_provider')
    def authorize_provider(provider_id: str, body: ProviderAuthorize, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='representation:*', tenant_id=principal.tenant_id, purpose=body.purpose, classification=body.classification)
        return _context(request).providers.authorize_execution(provider_id, classification=body.classification, purpose=body.purpose, region=body.region, external=body.external)

    @providers.post('/v1/models', status_code=201, operation_id='register_model')
    def register_model(body: ModelRegister, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:admin', tenant_id=principal.tenant_id)
        return _context(request).models.register(body.manifest)

    @providers.post('/v1/models/{model_id}/authorize', operation_id='authorize_model')
    def authorize_model(model_id: str, body: ModelAuthorize, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='representation:*', tenant_id=principal.tenant_id, purpose=body.purpose, classification=body.classification)
        return _context(request).models.authorize(model_id, checkpoint_hash=body.checkpoint_hash, purpose=body.purpose, commercial=body.commercial, classification=body.classification)

    @representation.post('/v1/projects/{project_id}/representations', status_code=201, operation_id='create_representation_candidate')
    def create_representation(project_id: str, body: RepresentationCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='representation:*', tenant_id=principal.tenant_id, project_id=project_id)
        identifier = _context(request).representations.create_candidate(tenant_id=principal.tenant_id, project_id=project_id, scene_id=body.scene_id, asset_id=body.asset_id, kind=body.kind, provider_id=body.provider_id, coordinate_frame_id=body.coordinate_frame_id, source_class=body.source_class, authority_class=body.authority_class, lossy=body.lossy, intended_uses=body.intended_uses, prohibited_uses=body.prohibited_uses, quality=body.quality, provenance=body.provenance, support_map=body.support_map, actor_id=principal.subject_id)
        return {'representation_id': identifier, 'state': 'quarantined'}

    @representation.post('/v1/representations/{representation_id}/quality-review', operation_id='review_representation')
    def review_representation(representation_id: str, body: RepresentationReview, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:review', tenant_id=principal.tenant_id)
        return _context(request).representations.review_quality(representation_id, reviewer_id=principal.subject_id, approved_uses=body.approved_uses, metrics=body.metrics, passed=body.passed)

    @representation.post('/v1/representations/{old_id}/replace/{new_id}', operation_id='replace_interaction_proxy')
    def replace_proxy(old_id: str, new_id: str, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='representation:*', tenant_id=principal.tenant_id)
        return _context(request).representations.replace_proxy(old_id, new_id)

    @publisher.post('/v1/representations/{representation_id}/publish', operation_id='publish_representation')
    def publish_representation(representation_id: str, body: RepresentationPublish, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='representation:publish', tenant_id=principal.tenant_id)
        return _context(request).publisher.publish(representation_id, commit_id=body.commit_id, role=body.role, publisher_id=principal.subject_id)

    @search.post('/v1/projects/{project_id}/search/documents', status_code=201, operation_id='index_search_document')
    def index_search(project_id: str, body: SearchIndex, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:*', tenant_id=principal.tenant_id, project_id=project_id)
        identifier = _context(request).search.index(tenant_id=principal.tenant_id, project_id=project_id, text=body.text, entity_id=body.entity_id, asset_id=body.asset_id, embedding=body.embedding, spatial_bounds=body.spatial_bounds, temporal_start=body.temporal_start, temporal_end=body.temporal_end, policy=body.policy)
        return {'document_id': identifier}

    @search.post('/v1/projects/{project_id}/search', operation_id='search_project')
    def query_search(project_id: str, body: SearchQuery, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:read', tenant_id=principal.tenant_id, project_id=project_id)
        result = _context(request).search.query(tenant_id=principal.tenant_id, project_id=project_id, text=body.text, embedding=body.embedding, point=body.point, at_time=body.at_time, allowed_audiences={audience.value for audience in body.allowed_audiences}, limit=body.limit)
        return {'items': result}

    @evidence.get('/v1/tenants/{tenant_id}/audit/verify', operation_id='verify_audit_chain')
    def verify_audit(tenant_id: str, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:admin', tenant_id=tenant_id)
        return _context(request).audit.verify(tenant_id)

    @export.post('/v1/projects/{project_id}/exports/preservation', status_code=202, operation_id='export_preservation')
    def export_preservation(project_id: str, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='export:*', tenant_id=principal.tenant_id, project_id=project_id)
        root = _context(request).settings.object_store_root.parent / 'exports'
        root.mkdir(parents=True, exist_ok=True)
        destination = root / f'{principal.tenant_id}-{project_id}-{new_uuid()}.sip-preservation.zip'
        return _context(request).preservation.export_project(principal.tenant_id, project_id, destination, actor_id=principal.subject_id)

    @construction.post('/v1/projects/{project_id}/construction/hierarchy', status_code=201, operation_id='create_construction_hierarchy')
    def construction_hierarchy(project_id: str, body: ConstructionHierarchy, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='construction:*', tenant_id=principal.tenant_id, project_id=project_id)
        identifier = _context(request).construction.create_hierarchy_item(tenant_id=principal.tenant_id, project_id=project_id, record_type=body.record_type, name=body.name, parent_id=body.parent_id, state=body.state, actor_id=principal.subject_id, attributes=body.attributes)
        return {'record_id': identifier}

    @construction.post('/v1/projects/{project_id}/construction/systems', status_code=201, operation_id='create_construction_system')
    def construction_system(project_id: str, body: ConstructionSystem, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='construction:*', tenant_id=principal.tenant_id, project_id=project_id)
        identifier = _context(request).construction.create_system_record(tenant_id=principal.tenant_id, project_id=project_id, system_type=body.system_type, parent_id=body.parent_id, entity_id=body.entity_id, state=body.state, data=body.data, evidence_asset_ids=body.evidence_asset_ids, actor_id=principal.subject_id)
        return {'record_id': identifier}

    @construction.post('/v1/projects/{project_id}/construction/documents', status_code=201, operation_id='attach_construction_document')
    def construction_document(project_id: str, body: ConstructionDocument, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='construction:*', tenant_id=principal.tenant_id, project_id=project_id)
        identifier = _context(request).construction.attach_document(tenant_id=principal.tenant_id, project_id=project_id, document_type=body.document_type, asset_id=body.asset_id, parent_id=body.parent_id, page_region=body.page_region, spatial_anchor=body.spatial_anchor, data=body.data, actor_id=principal.subject_id)
        return {'record_id': identifier}

    @construction.post('/v1/projects/{project_id}/construction/deficiencies', status_code=201, operation_id='create_deficiency')
    def create_deficiency(project_id: str, body: DeficiencyCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='construction:*', tenant_id=principal.tenant_id, project_id=project_id)
        identifier = _context(request).construction.create_deficiency(tenant_id=principal.tenant_id, project_id=project_id, entity_id=body.entity_id, description=body.description, severity=body.severity, evidence_asset_ids=body.evidence_asset_ids, actor_id=principal.subject_id)
        return {'deficiency_id': identifier}

    @construction.post('/v1/construction/deficiencies/{deficiency_id}/retest', operation_id='retest_deficiency')
    def retest_deficiency(deficiency_id: str, body: DeficiencyRetest, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='construction:*', tenant_id=principal.tenant_id)
        return _context(request).construction.correct_and_retest(deficiency_id, correction=body.correction, correction_asset_ids=body.correction_asset_ids, test_result=body.test_result, test_asset_ids=body.test_asset_ids, tester_id=principal.subject_id)

    @construction.get('/v1/projects/{project_id}/construction/reports/{report_type}', operation_id='get_construction_report')
    def construction_report(project_id: str, report_type: Literal['owner', 'technical'], request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='construction:read', tenant_id=principal.tenant_id, project_id=project_id)
        if report_type == 'owner':
            return _context(request).construction.owner_report(principal.tenant_id, project_id)
        return _context(request).construction.technical_report(principal.tenant_id, project_id)

    @memory.post('/v1/projects/{project_id}/liveforever/consents', status_code=201, operation_id='grant_consent')
    def grant_consent(project_id: str, body: ConsentGrantCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='consent:*', tenant_id=principal.tenant_id, project_id=project_id)
        grant_id = _context(request).liveforever.grant_consent(tenant_id=principal.tenant_id, project_id=project_id, subject_id=body.subject_id, granted_by=principal.subject_id, purposes=body.purposes, audiences=body.audiences, scopes=body.scopes, derivative_policy=body.derivative_policy, expires_at=body.expires_at)
        return {'grant_id': grant_id}

    @memory.post('/v1/liveforever/consents/{grant_id}/revoke', operation_id='revoke_consent')
    def revoke_consent(grant_id: str, body: ConsentRevoke, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='consent:*', tenant_id=principal.tenant_id)
        return _context(request).liveforever.revoke_consent(grant_id, actor_id=principal.subject_id, reason=body.reason)

    @memory.post('/v1/projects/{project_id}/liveforever/records', status_code=201, operation_id='create_memory_record')
    def create_memory(project_id: str, body: MemoryCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='liveforever:*', tenant_id=principal.tenant_id, project_id=project_id, purpose=body.purpose, audience=body.audience)
        record_id = _context(request).liveforever.create_record(tenant_id=principal.tenant_id, project_id=project_id, record_type=body.record_type, subject_id=body.subject_id, related_ids=body.related_ids, data=body.data, source_class=body.source_class, confidence=body.confidence, evidence_asset_ids=body.evidence_asset_ids, audience=body.audience, actor_id=principal.subject_id, purpose=body.purpose, generated_lineage=body.generated_lineage)
        return {'record_id': record_id}

    @memory.post('/v1/projects/{project_id}/liveforever/conflicting-recollections', status_code=201, operation_id='create_conflicting_recollections')
    def create_conflicts(project_id: str, body: ConflictingRecollections, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='liveforever:*', tenant_id=principal.tenant_id, project_id=project_id)
        return _context(request).liveforever.conflicting_recollections(tenant_id=principal.tenant_id, project_id=project_id, subject_id=body.subject_id, event_key=body.event_key, recollections=body.recollections, audience=body.audience, actor_id=principal.subject_id)

    @memory.post('/v1/projects/{project_id}/liveforever/experience', operation_id='configure_liveforever_experience')
    def configure_experience(project_id: str, body: ExperienceRequest, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='liveforever:read', tenant_id=principal.tenant_id, project_id=project_id, audience=body.audience)
        return _context(request).liveforever.experience_configuration(principal.tenant_id, project_id, body.subject_id, requested_features=body.requested_features, audience=body.audience)

    @memory.get('/v1/projects/{project_id}/liveforever/editions/{audience}', operation_id='get_liveforever_edition')
    def get_edition(project_id: str, audience: Audience, request: Request, principal: Principal, purpose: str=Query(...)) -> dict[str, Any]:
        _require(request, principal, action='liveforever:read', tenant_id=principal.tenant_id, project_id=project_id, purpose=purpose, audience=audience)
        return _context(request).liveforever.edition(principal.tenant_id, project_id, audience=audience, purpose=purpose)

    @collaboration.post('/v1/projects/{project_id}/comments', status_code=201, operation_id='create_comment')
    def create_comment(project_id: str, body: CommentCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:read', tenant_id=principal.tenant_id, project_id=project_id)
        comment_id = _context(request).collaboration.comment(tenant_id=principal.tenant_id, project_id=project_id, body=body.body, author_id=principal.subject_id, scene_commit_id=body.scene_commit_id, entity_id=body.entity_id, anchor=body.anchor, supersedes_comment_id=body.supersedes_comment_id)
        return {'comment_id': comment_id}

    @collaboration.post('/v1/projects/{project_id}/tasks', status_code=201, operation_id='create_task')
    def create_task(project_id: str, body: TaskCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:read', tenant_id=principal.tenant_id, project_id=project_id)
        task_id = _context(request).collaboration.create_task(tenant_id=principal.tenant_id, project_id=project_id, title=body.title, description=body.description, created_by=principal.subject_id, entity_id=body.entity_id, assignee_id=body.assignee_id, priority=body.priority, due_at=body.due_at)
        return {'task_id': task_id}

    @collaboration.post('/v1/tasks/{task_id}/transition', operation_id='transition_task')
    def transition_task(task_id: str, body: TaskTransition, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='scene:read', tenant_id=principal.tenant_id)
        return _context(request).collaboration.transition_task(task_id, new_state=body.state, actor_id=principal.subject_id)

    @notification.post('/v1/projects/{project_id}/notifications', status_code=202, operation_id='queue_notification')
    def queue_notification(project_id: str, body: NotificationCreate, request: Request, principal: Principal) -> dict[str, Any]:
        _require(request, principal, action='project:*', tenant_id=principal.tenant_id, project_id=project_id)
        notification_id = _context(request).notifications.queue(tenant_id=principal.tenant_id, project_id=project_id, recipient_id=body.recipient_id, channel=body.channel, template_id=body.template_id, payload=body.payload, sensitive=body.sensitive)
        return {'notification_id': notification_id}
    return {'control-api': control, 'identity-policy': identity, 'capture-service': capture, 'workflow-service': workflow, 'scene-service': scene, 'evidence-service': evidence, 'search-service': search, 'export-service': export, 'notification-service': notification, 'audit-service': audit, 'representation-api': representation, 'provider-registry': providers, 'representation-publisher': publisher, 'construction': construction, 'liveforever': memory, 'collaboration': collaboration}
SERVICE_DEPENDENCIES: dict[str, set[str]] = {'control-api': {'control-api', 'construction', 'liveforever', 'collaboration'}, 'all': set(_routers().keys())}

def create_app(*, context: PlatformContext | None=None, service_name: str | None=None) -> FastAPI:
    settings = context.settings if context else Settings.from_env()
    context = context or PlatformContext.create(settings)
    service_name = service_name or os.getenv('SIP_SERVICE_NAME', 'all')
    logger = configure_logging(service_name)
    telemetry = PlatformObservability.create(service_name)
    tracing_enabled = configure_tracing(service_name)
    app = FastAPI(title=f'Spatial Intelligence Platform — {service_name}', version=API_VERSION, openapi_version='3.1.0', docs_url='/docs' if settings.environment != 'production' else None, redoc_url=None)
    app.state.platform = context
    app.state.service_name = service_name
    app.state.observability = telemetry
    app.state.tracing_enabled = tracing_enabled
    app.add_middleware(CORSMiddleware, allow_origins=['http://localhost:3000'] if settings.environment != 'production' else [], allow_credentials=False, allow_methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'], allow_headers=['Authorization', 'Content-Type', 'Idempotency-Key', 'X-Request-ID'])

    @app.middleware('http')
    async def request_integrity(request: Request, call_next):
        supplied_request_id = request.headers.get('x-request-id', '')
        request_id = (
            supplied_request_id
            if 0 < len(supplied_request_id) <= 128
            and supplied_request_id.replace('-', '').replace('_', '').isalnum()
            else new_uuid()
        )
        request.state.request_id = request_id
        content_length = request.headers.get('content-length')
        timer = RequestTimer()
        telemetry.in_flight.labels(service=service_name).inc()
        status = 500
        error_code = 'none'
        response: Response | None = None

        def correlated_error(code: str, message: str, status_code: int, *, retryable: bool=False) -> JSONResponse:
            nonlocal error_code
            error_code = code
            request.state.error_code = code
            trace_id = current_trace_id() or 'none'
            request.state.trace_id = trace_id
            return JSONResponse(
                status_code=status_code,
                content={
                    'error': {
                        'code': code,
                        'message': message,
                        'details': {},
                        'retryable': retryable,
                        'correlation': {'request_id': request_id, 'trace_id': trace_id},
                    }
                },
            )

        def secure_response(response_value: Response) -> Response:
            response_value.headers['X-Request-ID'] = request_id
            response_value.headers['X-Trace-ID'] = getattr(request.state, 'trace_id', 'none')
            response_value.headers['X-Content-Type-Options'] = 'nosniff'
            response_value.headers['Referrer-Policy'] = 'no-referrer'
            response_value.headers['X-Frame-Options'] = 'DENY'
            response_value.headers['Content-Security-Policy'] = "default-src 'none'; frame-ancestors 'none'"
            response_value.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=(), payment=()'
            response_value.headers['Cache-Control'] = 'no-store' if request.url.path.startswith('/v1') else 'no-cache'
            if settings.environment == 'production':
                response_value.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            return response_value

        with server_span(service_name=service_name, method=request.method) as span:
            trace_id = current_trace_id() or 'none'
            request.state.trace_id = trace_id
            with bind_telemetry_context(BoundTelemetryContext(request_id=request_id, trace_id=trace_id)):
                try:
                    if content_length:
                        try:
                            parsed_length = int(content_length)
                        except ValueError:
                            response = correlated_error(
                                'CONTENT_LENGTH_INVALID',
                                'content-length must be an integer',
                                400,
                            )
                        else:
                            if parsed_length < 0:
                                response = correlated_error(
                                    'CONTENT_LENGTH_INVALID',
                                    'content-length must be non-negative',
                                    400,
                                )
                            elif parsed_length > settings.max_api_body_bytes:
                                response = correlated_error(
                                    'BODY_TOO_LARGE',
                                    'request body exceeds configured limit',
                                    413,
                                )
                    if response is None:
                        response = await call_next(request)
                    status = response.status_code
                    return secure_response(response)
                except Exception as exc:
                    error_code = 'INTERNAL_ERROR'
                    status = 500
                    telemetry.observe_error(error_code=error_code, outcome='unhandled_error')
                    logger.exception(
                        'unhandled request failure',
                        extra={
                            'request_id': request_id,
                            'trace_id': current_trace_id() or 'none',
                            'event': 'http.request.unhandled_error',
                            'outcome': 'unhandled_error',
                            'error_code': error_code,
                            'fields': {
                                'method': request.method,
                                'route': getattr(request.scope.get('route'), 'path', '__unmatched__'),
                                'exception_type': type(exc).__name__,
                            },
                        },
                    )
                    return secure_response(
                        correlated_error(
                            'INTERNAL_ERROR',
                            'the request could not be completed',
                            500,
                            retryable=True,
                        )
                    )
                finally:
                    route_object = request.scope.get('route')
                    route = getattr(route_object, 'path', None) or '__unmatched__'
                    principal = getattr(request.state, 'principal', None)
                    tenant_context = pseudonymize_identifier(
                        getattr(principal, 'tenant_id', None),
                        namespace='tenant',
                        key=settings.signing_key,
                    )
                    project_id = request.path_params.get('project_id') if request.path_params else None
                    project_context = pseudonymize_identifier(
                        project_id,
                        namespace='project',
                        key=settings.signing_key,
                    )
                    error_code = getattr(request.state, 'error_code', error_code)
                    outcome = 'success' if status < 400 else ('client_error' if status < 500 else 'server_error')
                    telemetry.observe(method=request.method, route=route, status=status, duration_seconds=timer.elapsed)
                    telemetry.in_flight.labels(service=service_name).dec()
                    if span is not None:
                        try:
                            span.update_name(f'{request.method} {route}')
                            span.set_attribute('http.route', route)
                            span.set_attribute('http.response.status_code', status)
                            span.set_attribute('sip.outcome', outcome)
                            span.set_attribute('sip.error_code', error_code)
                        except Exception:
                            pass
                    with bind_telemetry_context(
                        BoundTelemetryContext(
                            request_id=request_id,
                            trace_id=current_trace_id() or trace_id,
                            tenant_context=tenant_context,
                            project_context=project_context,
                        )
                    ):
                        logger.info(
                            'http request complete',
                            extra={
                                'event': 'http.request.complete',
                                'outcome': outcome,
                                'error_code': error_code,
                                'fields': {
                                    'method': request.method,
                                    'route': route,
                                    'status': status,
                                    'duration_seconds': round(timer.elapsed, 6),
                                },
                            },
                        )

    @app.exception_handler(SIPError)
    async def sip_error_handler(request: Request, exc: SIPError) -> JSONResponse:
        request_id = getattr(request.state, 'request_id', 'none')
        trace_id = current_trace_id() or getattr(request.state, 'trace_id', 'none')
        request.state.trace_id = trace_id
        request.state.error_code = exc.code
        telemetry.observe_error(error_code=exc.code, outcome='handled_error')
        logger.warning(
            'request rejected',
            extra={
                'request_id': request_id,
                'trace_id': trace_id,
                'event': 'http.request.rejected',
                'outcome': 'handled_error',
                'error_code': exc.code,
                'fields': {'status': exc.status_code, 'retryable': exc.retryable},
            },
        )
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.as_dict(request_id=request_id, trace_id=trace_id),
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, _: ValueError) -> JSONResponse:
        request_id = getattr(request.state, 'request_id', 'none')
        trace_id = current_trace_id() or getattr(request.state, 'trace_id', 'none')
        request.state.error_code = 'VALUE_INVALID'
        telemetry.observe_error(error_code='VALUE_INVALID', outcome='handled_error')
        return JSONResponse(
            status_code=400,
            content={
                'error': {
                    'code': 'VALUE_INVALID',
                    'message': 'request value is invalid',
                    'details': {},
                    'retryable': False,
                    'correlation': {'request_id': request_id, 'trace_id': trace_id},
                }
            },
        )

    @app.get('/health/live', operation_id='health_live')
    def health_live() -> dict[str, Any]:
        return {'status': 'live', 'service': service_name, 'version': API_VERSION}

    @app.get('/health/ready', operation_id='health_ready')
    def health_ready() -> dict[str, Any]:
        try:
            with context.database.session() as session:
                session.execute(__import__('sqlalchemy').text('SELECT 1'))
        except Exception:
            telemetry.readiness_failures.labels(service=service_name, dependency='database').inc()
            raise
        try:
            context.store.probe()
        except Exception:
            telemetry.readiness_failures.labels(service=service_name, dependency='object_store').inc()
            raise
        return {'status': 'ready', 'service': service_name, 'database': 'ok', 'object_store': 'ok', 'tracing': tracing_enabled, 'version': API_VERSION}

    @app.get('/metrics', include_in_schema=False)
    def metrics() -> Response:
        return Response(content=telemetry.render(), media_type='text/plain; version=0.0.4; charset=utf-8')

    routers = _routers()
    selected = SERVICE_DEPENDENCIES.get(service_name, {service_name})
    unknown = selected - routers.keys()
    if unknown:
        raise RuntimeError(f'unknown SIP service boundary: {sorted(unknown)}')
    for name in sorted(selected):
        app.include_router(routers[name])
    return app
app = create_app(service_name=os.getenv('SIP_SERVICE_NAME', 'all'))

def main() -> None:
    import uvicorn
    uvicorn.run('sip.api:app', host='0.0.0.0', port=int(os.getenv('PORT', '8080')), proxy_headers=True)
