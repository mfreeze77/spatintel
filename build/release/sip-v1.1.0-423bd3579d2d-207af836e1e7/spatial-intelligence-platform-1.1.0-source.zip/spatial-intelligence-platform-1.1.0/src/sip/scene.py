from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sqlalchemy import select

from .audit import AuditService
from .canonical import canonical_sha256, new_uuid
from .database import (
    Database,
    MeasurementRow,
    RepresentationAssetRow,
    RepresentationBindingRow,
    SceneBranchRow,
    SceneCommitRow,
    SceneEntityRow,
)
from .errors import ConflictError, NotFoundError, ValidationError
from .models import AuthorityClass, ProvenanceRef, SourceClass
from .temporal import db_now


@dataclass(frozen=True)
class ProxyHit:
    representation_id: str
    world_point: list[float]
    normal: list[float] | None
    support_hint: dict[str, Any]


class SceneService:
    def __init__(self, database: Database, audit: AuditService) -> None:
        self.database = database
        self.audit = audit

    def create_scene(self, tenant_id: str, project_id: str, *, name: str, actor_id: str) -> dict[str, str]:
        scene_id = new_uuid()
        initial = {"scene_id": scene_id, "name": name, "entities": [], "representations": [], "schema_version": "1.0.0"}
        commit_id = new_uuid()
        with self.database.session() as session:
            session.add(
                SceneCommitRow(
                    commit_id=commit_id,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    branch="main",
                    parent_ids_json=[],
                    message="Initialize scene",
                    semantic_snapshot_json=initial,
                    snapshot_hash=canonical_sha256(initial),
                    created_by=actor_id,
                )
            )
            session.add(
                SceneBranchRow(
                    branch_id=new_uuid(),
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    name="main",
                    head_commit_id=commit_id,
                    protected=True,
                )
            )
            self.audit.append(
                tenant_id=tenant_id,
                project_id=project_id,
                actor_id=actor_id,
                action="scene:create",
                resource_type="scene",
                resource_id=scene_id,
                outcome="allowed",
                details={"commit_id": commit_id},
                session=session,
            )
        return {"scene_id": scene_id, "commit_id": commit_id, "branch": "main"}

    def create_entity(
        self,
        *,
        tenant_id: str,
        project_id: str,
        scene_id: str,
        entity_type: str,
        name: str,
        attributes: dict[str, Any],
        source_class: SourceClass,
        authority_class: AuthorityClass,
        confidence: float,
        provenance: ProvenanceRef,
        policy: dict[str, Any],
        stable_support: dict[str, Any],
        actor_id: str,
        entity_id: str | None = None,
    ) -> str:
        if not 0 <= confidence <= 1:
            raise ValidationError("CONFIDENCE_INVALID", "confidence must be between zero and one")
        if any(key in stable_support for key in {"triangle_id", "gaussian_id", "voxel_id", "tile_id", "lod_element_id"}):
            raise ValidationError("UNSTABLE_SUPPORT_IDENTIFIER", "durable entity supports cannot depend on geometry element IDs")
        identifier = entity_id or new_uuid()
        with self.database.session() as session:
            if session.get(SceneEntityRow, identifier):
                raise ConflictError("ENTITY_EXISTS", "stable entity identifier already exists")
            session.add(
                SceneEntityRow(
                    entity_id=identifier,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    entity_type=entity_type,
                    name=name,
                    attributes_json=attributes,
                    source_class=source_class.value,
                    authority_class=authority_class.value,
                    confidence=confidence,
                    provenance_json=provenance.model_dump(mode="json"),
                    policy_json=policy,
                    stable_support_json=stable_support,
                )
            )
            self.audit.append(
                tenant_id=tenant_id,
                project_id=project_id,
                actor_id=actor_id,
                action="scene_entity:create",
                resource_type="scene_entity",
                resource_id=identifier,
                outcome="allowed",
                details={"scene_id": scene_id, "entity_type": entity_type, "source_class": source_class.value},
                session=session,
            )
        return identifier

    def commit(
        self,
        *,
        tenant_id: str,
        project_id: str,
        scene_id: str,
        branch: str,
        expected_head: str,
        message: str,
        actor_id: str,
    ) -> dict[str, Any]:
        with self.database.session() as session:
            branch_row = session.scalar(
                select(SceneBranchRow).where(
                    SceneBranchRow.tenant_id == tenant_id,
                    SceneBranchRow.project_id == project_id,
                    SceneBranchRow.scene_id == scene_id,
                    SceneBranchRow.name == branch,
                )
            )
            if not branch_row:
                raise NotFoundError("scene_branch", branch)
            if branch_row.head_commit_id != expected_head:
                raise ConflictError(
                    "SCENE_HEAD_CHANGED",
                    "scene branch changed since the client read it",
                    {"expected": expected_head, "actual": branch_row.head_commit_id},
                )
            entities = list(
                session.scalars(
                    select(SceneEntityRow).where(
                        SceneEntityRow.tenant_id == tenant_id,
                        SceneEntityRow.project_id == project_id,
                        SceneEntityRow.scene_id == scene_id,
                        SceneEntityRow.superseded_at.is_(None),
                    )
                )
            )
            bindings = list(
                session.scalars(
                    select(RepresentationBindingRow).where(
                        RepresentationBindingRow.tenant_id == tenant_id,
                        RepresentationBindingRow.project_id == project_id,
                        RepresentationBindingRow.scene_id == scene_id,
                        RepresentationBindingRow.superseded_at.is_(None),
                    )
                )
            )
            snapshot = {
                "schema_version": "1.0.0",
                "scene_id": scene_id,
                "entities": [
                    {
                        "entity_id": item.entity_id,
                        "entity_type": item.entity_type,
                        "name": item.name,
                        "attributes": item.attributes_json,
                        "source_class": item.source_class,
                        "authority_class": item.authority_class,
                        "confidence": item.confidence,
                        "provenance": item.provenance_json,
                        "policy": item.policy_json,
                        "stable_support": item.stable_support_json,
                    }
                    for item in sorted(entities, key=lambda value: value.entity_id)
                ],
                "representations": [
                    {"binding_id": item.binding_id, "representation_id": item.representation_id, "role": item.role}
                    for item in sorted(bindings, key=lambda value: value.binding_id)
                ],
            }
            commit_id = new_uuid()
            row = SceneCommitRow(
                commit_id=commit_id,
                tenant_id=tenant_id,
                project_id=project_id,
                scene_id=scene_id,
                branch=branch,
                parent_ids_json=[expected_head],
                message=message,
                semantic_snapshot_json=snapshot,
                snapshot_hash=canonical_sha256(snapshot),
                created_by=actor_id,
            )
            session.add(row)
            branch_row.head_commit_id = commit_id
            self.audit.append(
                tenant_id=tenant_id,
                project_id=project_id,
                actor_id=actor_id,
                action="scene:commit",
                resource_type="scene_commit",
                resource_id=commit_id,
                outcome="allowed",
                details={"scene_id": scene_id, "branch": branch, "parent": expected_head, "snapshot_hash": row.snapshot_hash},
                session=session,
            )
            return {"commit_id": commit_id, "snapshot_hash": row.snapshot_hash, "parent_ids": [expected_head], "branch": branch}

    def create_branch(
        self,
        tenant_id: str,
        project_id: str,
        scene_id: str,
        *,
        name: str,
        from_commit_id: str,
        protected: bool = False,
    ) -> str:
        with self.database.session() as session:
            commit = session.get(SceneCommitRow, from_commit_id)
            if not commit or commit.tenant_id != tenant_id or commit.project_id != project_id or commit.scene_id != scene_id:
                raise NotFoundError("scene_commit", from_commit_id)
            existing = session.scalar(
                select(SceneBranchRow).where(
                    SceneBranchRow.tenant_id == tenant_id,
                    SceneBranchRow.project_id == project_id,
                    SceneBranchRow.scene_id == scene_id,
                    SceneBranchRow.name == name,
                )
            )
            if existing:
                raise ConflictError("BRANCH_EXISTS", "scene branch already exists")
            branch_id = new_uuid()
            session.add(
                SceneBranchRow(
                    branch_id=branch_id,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    name=name,
                    head_commit_id=from_commit_id,
                    protected=protected,
                )
            )
            return branch_id

    def diff(self, left_commit_id: str, right_commit_id: str) -> dict[str, Any]:
        with self.database.session() as session:
            left = session.get(SceneCommitRow, left_commit_id)
            right = session.get(SceneCommitRow, right_commit_id)
            if not left or not right or left.tenant_id != right.tenant_id or left.project_id != right.project_id or left.scene_id != right.scene_id:
                raise ValidationError("SCENE_DIFF_SCOPE_MISMATCH", "commits must exist in the same scene")
            left_entities = {item["entity_id"]: item for item in left.semantic_snapshot_json.get("entities", [])}
            right_entities = {item["entity_id"]: item for item in right.semantic_snapshot_json.get("entities", [])}
            added = sorted(set(right_entities) - set(left_entities))
            removed = sorted(set(left_entities) - set(right_entities))
            modified = sorted(key for key in set(left_entities) & set(right_entities) if left_entities[key] != right_entities[key])
            return {
                "left": left_commit_id,
                "right": right_commit_id,
                "entities": {"added": added, "removed": removed, "modified": modified},
                "representation_changed": left.semantic_snapshot_json.get("representations") != right.semantic_snapshot_json.get("representations"),
            }

    def rollback_branch(self, tenant_id: str, project_id: str, scene_id: str, branch: str, target_commit_id: str, *, actor_id: str) -> dict[str, Any]:
        with self.database.session() as session:
            target = session.get(SceneCommitRow, target_commit_id)
            branch_row = session.scalar(
                select(SceneBranchRow).where(
                    SceneBranchRow.tenant_id == tenant_id,
                    SceneBranchRow.project_id == project_id,
                    SceneBranchRow.scene_id == scene_id,
                    SceneBranchRow.name == branch,
                )
            )
            if not target or not branch_row or target.scene_id != scene_id:
                raise NotFoundError("scene_commit", target_commit_id)
            previous = branch_row.head_commit_id
            rollback_id = new_uuid()
            session.add(
                SceneCommitRow(
                    commit_id=rollback_id,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    branch=branch,
                    parent_ids_json=[previous],
                    message=f"Rollback semantic state to {target_commit_id}",
                    semantic_snapshot_json=target.semantic_snapshot_json,
                    snapshot_hash=target.snapshot_hash,
                    created_by=actor_id,
                    supersedes_commit_id=previous,
                )
            )
            branch_row.head_commit_id = rollback_id
            return {"commit_id": rollback_id, "restored_from": target_commit_id, "superseded": previous, "snapshot_hash": target.snapshot_hash}

    def create_measurement(
        self,
        *,
        tenant_id: str,
        project_id: str,
        scene_id: str,
        entity_id: str | None,
        value: float,
        unit: str,
        uncertainty: float,
        source_asset_ids: list[str],
        calibration: dict[str, Any],
        verifier_id: str | None,
        verified: bool,
        actor_id: str,
        originating_representation_id: str | None = None,
    ) -> str:
        if uncertainty < 0 or not source_asset_ids:
            raise ValidationError("MEASUREMENT_EVIDENCE_REQUIRED", "measurement requires non-negative uncertainty and source evidence")
        with self.database.session() as session:
            if originating_representation_id:
                rep = session.get(RepresentationAssetRow, originating_representation_id)
                if not rep:
                    raise NotFoundError("representation", originating_representation_id)
                if rep.kind in {"interaction", "visual"}:
                    raise ValidationError(
                        "NON_AUTHORITATIVE_MEASUREMENT_SOURCE",
                        "proxy and visual representations cannot directly create measurements",
                        {"representation_id": originating_representation_id, "kind": rep.kind},
                    )
            if verified and (not verifier_id or not calibration or uncertainty == 0):
                raise ValidationError("VERIFIED_MEASUREMENT_METADATA_REQUIRED", "verified measurement requires verifier, calibration, and explicit uncertainty")
            measurement_id = new_uuid()
            session.add(
                MeasurementRow(
                    measurement_id=measurement_id,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    scene_id=scene_id,
                    entity_id=entity_id,
                    value=value,
                    unit=unit,
                    uncertainty=uncertainty,
                    source_asset_ids_json=source_asset_ids,
                    calibration_json=calibration,
                    verifier_id=verifier_id,
                    verified_at=db_now() if verified else None,
                    authority_class=AuthorityClass.FIELD_VERIFIED.value if verified else AuthorityClass.METRIC.value,
                    created_by=actor_id,
                )
            )
            return measurement_id

    def resolve_proxy_hit(self, tenant_id: str, project_id: str, hit: ProxyHit, *, tolerance_m: float = 0.03) -> dict[str, Any]:
        with self.database.session() as session:
            proxy = session.get(RepresentationAssetRow, hit.representation_id)
            if not proxy or proxy.tenant_id != tenant_id or proxy.project_id != project_id:
                raise NotFoundError("representation", hit.representation_id)
            if proxy.kind != "interaction":
                raise ValidationError("PROXY_HIT_KIND_INVALID", "hit does not originate from an interaction representation")
            metric_id = proxy.support_map_json.get("metric_representation_id")
            metric = session.get(RepresentationAssetRow, metric_id) if metric_id else None
            if not metric or metric.kind != "metric" or metric.state != "published":
                return {
                    "resolved": False,
                    "reason": "eligible_metric_support_unavailable",
                    "proxy_representation_id": hit.representation_id,
                    "authoritative_measurement_allowed": False,
                }
            residual = float(proxy.support_map_json.get("max_reprojection_error_m", 999.0))
            resolved = residual <= tolerance_m
            return {
                "resolved": resolved,
                "metric_representation_id": metric.representation_id,
                "world_point": hit.world_point,
                "estimated_residual_m": residual,
                "authoritative_measurement_allowed": resolved and metric.authority_class in {AuthorityClass.METRIC.value, AuthorityClass.FIELD_VERIFIED.value},
            }
