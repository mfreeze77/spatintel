from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from .canonical import canonical_sha256
from .database import Database, ModelManifestRow
from .errors import AuthorizationError, ValidationError
from .models import Classification
from .temporal import db_now


class ModelRegistry:
    def __init__(self, database: Database) -> None:
        self.database = database

    def register(self, manifest: dict[str, Any]) -> dict[str, Any]:
        required = {
            "model_id",
            "version",
            "checkpoint_hash",
            "code_revision",
            "code_license",
            "weights_license",
            "dataset_terms",
            "output_terms",
            "approval_state",
            "commercial_use",
            "allowed_purposes",
        }
        missing = sorted(required - manifest.keys())
        if missing:
            raise ValidationError("MODEL_MANIFEST_INCOMPLETE", "model manifest is incomplete", {"missing": missing})
        body = {key: manifest[key] for key in sorted(manifest) if key not in {"manifest_hash", "signature"}}
        digest = canonical_sha256(body)
        values = dict(
            model_id=manifest["model_id"],
            version=manifest["version"],
            checkpoint_hash=manifest["checkpoint_hash"],
            code_revision=manifest["code_revision"],
            code_license=manifest["code_license"],
            weights_license=manifest["weights_license"],
            dataset_terms_json=manifest["dataset_terms"],
            output_terms=manifest["output_terms"],
            approval_state=manifest["approval_state"],
            commercial_use=bool(manifest["commercial_use"]),
            allowed_purposes_json=manifest["allowed_purposes"],
            expires_at=_parse_datetime(manifest.get("expires_at")),
            manifest_hash=digest,
        )
        with self.database.session() as session:
            row = session.get(ModelManifestRow, manifest["model_id"])
            if row:
                for key, value in values.items():
                    setattr(row, key, value)
            else:
                session.add(ModelManifestRow(**values))
        return {"model_id": manifest["model_id"], "manifest_hash": digest, "approval_state": manifest["approval_state"]}

    def authorize(
        self,
        model_id: str,
        *,
        checkpoint_hash: str,
        purpose: str,
        commercial: bool,
        classification: Classification,
    ) -> dict[str, Any]:
        with self.database.session() as session:
            row = session.get(ModelManifestRow, model_id)
            if not row:
                raise AuthorizationError("MODEL_NOT_REGISTERED", "model execution is denied without a manifest")
            reasons: list[str] = []
            if row.approval_state != "approved":
                reasons.append("not_approved")
            if row.checkpoint_hash != checkpoint_hash:
                reasons.append("checkpoint_hash_mismatch")
            if purpose not in row.allowed_purposes_json:
                reasons.append("purpose_not_allowed")
            if commercial and not row.commercial_use:
                reasons.append("commercial_use_not_allowed")
            if row.expires_at and _aware(row.expires_at) <= db_now():
                reasons.append("approval_expired")
            if classification in {Classification.CRITICAL_INFRASTRUCTURE, Classification.BIOMETRIC, Classification.MINOR} and "sensitive_local" not in row.allowed_purposes_json:
                reasons.append("sensitive_data_not_approved")
            if row.weights_license.lower() in {"unknown", "research-only", "noncommercial", "non-commercial"}:
                reasons.append("weights_license_incompatible")
            if reasons:
                raise AuthorizationError("MODEL_EXECUTION_DENIED", "model governance gate denied execution", {"reasons": reasons})
            return {"allowed": True, "model_id": model_id, "manifest_hash": row.manifest_hash, "checkpoint_hash": row.checkpoint_hash}


def lingbot_source_manifest() -> dict[str, Any]:
    return {
        "provider_id": "lingbot-map-source-adapter",
        "version": "1.1.0",
        "source_url": "https://github.com/Robbyant/lingbot-map",
        "source_revision": "1f480aeb8a47a24656090d46d053115b7fe60435",
        "license_id": "Apache-2.0",
        "approval_state": "approved",
        "allowed_classifications": ["public", "internal"],
        "allowed_purposes": ["synthetic_evaluation", "research_shadow"],
        "allowed_regions": ["local"],
        "retention_days": 0,
        "notes": "Source approval does not approve any checkpoint, training data, or commercial model use.",
    }


def lingbot_checkpoint_denied_manifest() -> dict[str, Any]:
    return {
        "model_id": "lingbot-map-checkpoint",
        "version": "unapproved",
        "checkpoint_hash": "UNAVAILABLE",
        "code_revision": "1f480aeb8a47a24656090d46d053115b7fe60435",
        "code_license": "Apache-2.0",
        "weights_license": "unknown",
        "dataset_terms": ["unknown"],
        "output_terms": "unknown",
        "approval_state": "denied",
        "commercial_use": False,
        "allowed_purposes": ["synthetic_evaluation"],
    }


def _parse_datetime(value: str | datetime | None) -> datetime | None:
    if value is None or isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _aware(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=UTC)
