from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint, create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from .temporal import db_now


class Base(DeclarativeBase):
    """Declarative root for every canonical SIP persistence model."""


class TenantRow(Base):
    __tablename__ = "tenants"
    tenant_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(256))
    status: Mapped[str] = mapped_column(String(32), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class ProjectRow(Base):
    __tablename__ = "projects"
    project_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="RESTRICT"), index=True)
    name: Mapped[str] = mapped_column(String(256))
    vertical: Mapped[str] = mapped_column(String(64), default="platform")
    classification: Mapped[str] = mapped_column(String(64), default="internal")
    status: Mapped[str] = mapped_column(String(32), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class IdentityRow(Base):
    __tablename__ = "identities"
    identity_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="RESTRICT"), index=True)
    identity_type: Mapped[str] = mapped_column(String(32), default="user")
    display_name: Mapped[str] = mapped_column(String(256))
    disabled: Mapped[bool] = mapped_column(Boolean, default=False)
    attributes_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class RoleBindingRow(Base):
    __tablename__ = "role_bindings"
    binding_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="RESTRICT"), index=True)
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.project_id", ondelete="RESTRICT"), index=True)
    identity_id: Mapped[str] = mapped_column(ForeignKey("identities.identity_id", ondelete="RESTRICT"), index=True)
    role: Mapped[str] = mapped_column(String(64))
    purposes_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    spatial_restrictions_json: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class AssetRow(Base):
    __tablename__ = "assets"
    sha256: Mapped[str] = mapped_column(String(64), primary_key=True)
    byte_count: Mapped[int] = mapped_column(Integer)
    media_type: Mapped[str] = mapped_column(String(256))
    storage_key: Mapped[str] = mapped_column(Text)
    encryption_metadata: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class AssetRefRow(Base):
    __tablename__ = "asset_refs"
    asset_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="RESTRICT"), index=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.project_id", ondelete="RESTRICT"), index=True)
    sha256: Mapped[str] = mapped_column(ForeignKey("assets.sha256", ondelete="RESTRICT"), index=True)
    original_name: Mapped[str] = mapped_column(String(512))
    classification: Mapped[str] = mapped_column(String(64))
    retention_class: Mapped[str] = mapped_column(String(64))
    source_class: Mapped[str] = mapped_column(String(64))
    authority_class: Mapped[str] = mapped_column(String(64))
    provenance_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    legal_hold: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    tombstoned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MultipartUploadRow(Base):
    __tablename__ = "multipart_uploads"
    upload_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    expected_sha256: Mapped[str] = mapped_column(String(64))
    expected_bytes: Mapped[int] = mapped_column(Integer)
    media_type: Mapped[str] = mapped_column(String(256))
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    state: Mapped[str] = mapped_column(String(32), default="open")
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MultipartChunkRow(Base):
    __tablename__ = "multipart_chunks"
    chunk_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    upload_id: Mapped[str] = mapped_column(ForeignKey("multipart_uploads.upload_id", ondelete="CASCADE"), index=True)
    part_number: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    byte_count: Mapped[int] = mapped_column(Integer)
    path: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    __table_args__ = (UniqueConstraint("upload_id", "part_number", name="uq_upload_part"),)


class AuditEventRow(Base):
    __tablename__ = "audit_events"
    audit_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str | None] = mapped_column(String(64), index=True)
    actor_id: Mapped[str] = mapped_column(String(128))
    action: Mapped[str] = mapped_column(String(128), index=True)
    resource_type: Mapped[str] = mapped_column(String(128))
    resource_id: Mapped[str] = mapped_column(String(128))
    outcome: Mapped[str] = mapped_column(String(32))
    details_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    previous_hash: Mapped[str] = mapped_column(String(64))
    event_hash: Mapped[str] = mapped_column(String(64), unique=True)
    signature: Mapped[str] = mapped_column(String(128))


class OperationRow(Base):
    __tablename__ = "operations"
    operation_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    operation_type: Mapped[str] = mapped_column(String(128), index=True)
    idempotency_key: Mapped[str] = mapped_column(String(256))
    input_manifest_hash: Mapped[str] = mapped_column(String(64))
    input_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    state: Mapped[str] = mapped_column(String(32), default="pending", index=True)
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    attempt: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3)
    lease_owner: Mapped[str | None] = mapped_column(String(128))
    lease_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    checkpoint_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    output_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    output_hash: Mapped[str | None] = mapped_column(String(64))
    error_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now, onupdate=db_now)
    __table_args__ = (UniqueConstraint("tenant_id", "project_id", "operation_type", "idempotency_key", name="uq_operation_idempotency"),)


class OutboxEventRow(Base):
    __tablename__ = "outbox_events"
    event_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str | None] = mapped_column(String(64), index=True)
    event_type: Mapped[str] = mapped_column(String(128), index=True)
    schema_version: Mapped[str] = mapped_column(String(32))
    aggregate_type: Mapped[str] = mapped_column(String(128))
    aggregate_id: Mapped[str] = mapped_column(String(128))
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    payload_hash: Mapped[str] = mapped_column(String(64))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    delivery_attempts: Mapped[int] = mapped_column(Integer, default=0)


class CoordinateFrameRow(Base):
    __tablename__ = "coordinate_frames"
    frame_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    name: Mapped[str] = mapped_column(String(256))
    parent_frame_id: Mapped[str | None] = mapped_column(String(64), index=True)
    convention: Mapped[str] = mapped_column(String(128))
    units: Mapped[str] = mapped_column(String(32))
    transform_json: Mapped[list[list[float]] | None] = mapped_column(JSON)
    uncertainty_m: Mapped[float | None] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class SceneCommitRow(Base):
    __tablename__ = "scene_commits"
    commit_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_id: Mapped[str] = mapped_column(String(64), index=True)
    branch: Mapped[str] = mapped_column(String(128), default="main")
    parent_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    message: Mapped[str] = mapped_column(Text)
    semantic_snapshot_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    snapshot_hash: Mapped[str] = mapped_column(String(64))
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    supersedes_commit_id: Mapped[str | None] = mapped_column(String(64))


class SceneBranchRow(Base):
    __tablename__ = "scene_branches"
    branch_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_id: Mapped[str] = mapped_column(String(64), index=True)
    name: Mapped[str] = mapped_column(String(128))
    head_commit_id: Mapped[str] = mapped_column(String(64))
    protected: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("tenant_id", "project_id", "scene_id", "name", name="uq_scene_branch"),)


class SceneEntityRow(Base):
    __tablename__ = "scene_entities"
    entity_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_id: Mapped[str] = mapped_column(String(64), index=True)
    entity_type: Mapped[str] = mapped_column(String(128), index=True)
    name: Mapped[str] = mapped_column(String(512))
    attributes_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    source_class: Mapped[str] = mapped_column(String(64))
    authority_class: Mapped[str] = mapped_column(String(64))
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    provenance_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    policy_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    stable_support_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class RepresentationAssetRow(Base):
    __tablename__ = "representations"
    representation_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_id: Mapped[str] = mapped_column(String(64), index=True)
    asset_id: Mapped[str] = mapped_column(String(64), index=True)
    operation_id: Mapped[str | None] = mapped_column(String(64), index=True)
    kind: Mapped[str] = mapped_column(String(32), index=True)
    provider_id: Mapped[str] = mapped_column(String(128), index=True)
    coordinate_frame_id: Mapped[str] = mapped_column(String(64))
    source_class: Mapped[str] = mapped_column(String(64))
    authority_class: Mapped[str] = mapped_column(String(64))
    lossy: Mapped[bool] = mapped_column(Boolean, default=False)
    intended_uses_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    prohibited_uses_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    quality_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    provenance_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    support_map_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    state: Mapped[str] = mapped_column(String(32), default="quarantined")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    __table_args__ = (
        UniqueConstraint("tenant_id", "project_id", "operation_id", name="uq_representation_operation"),
    )


class RepresentationBindingRow(Base):
    __tablename__ = "representation_bindings"
    binding_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_id: Mapped[str] = mapped_column(String(64), index=True)
    commit_id: Mapped[str] = mapped_column(String(64), index=True)
    representation_id: Mapped[str] = mapped_column(String(64), index=True)
    role: Mapped[str] = mapped_column(String(64))
    published_by: Mapped[str] = mapped_column(String(128))
    published_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ProviderManifestRow(Base):
    __tablename__ = "provider_manifests"
    provider_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    version: Mapped[str] = mapped_column(String(64))
    source_url: Mapped[str] = mapped_column(Text)
    source_revision: Mapped[str] = mapped_column(String(128))
    image_digest: Mapped[str | None] = mapped_column(String(128))
    license_id: Mapped[str] = mapped_column(String(128))
    approval_state: Mapped[str] = mapped_column(String(32), default="denied")
    allowed_classifications_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    allowed_purposes_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    allowed_regions_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    retention_days: Mapped[int | None] = mapped_column(Integer)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    manifest_hash: Mapped[str] = mapped_column(String(64))
    signed_by: Mapped[str | None] = mapped_column(String(128))


class ModelManifestRow(Base):
    __tablename__ = "model_manifests"
    model_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    version: Mapped[str] = mapped_column(String(64))
    checkpoint_hash: Mapped[str] = mapped_column(String(128))
    code_revision: Mapped[str] = mapped_column(String(128))
    code_license: Mapped[str] = mapped_column(String(128))
    weights_license: Mapped[str] = mapped_column(String(128))
    dataset_terms_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    output_terms: Mapped[str] = mapped_column(Text, default="unknown")
    approval_state: Mapped[str] = mapped_column(String(32), default="denied")
    commercial_use: Mapped[bool] = mapped_column(Boolean, default=False)
    allowed_purposes_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    manifest_hash: Mapped[str] = mapped_column(String(64))


class MeasurementRow(Base):
    __tablename__ = "measurements"
    measurement_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_id: Mapped[str] = mapped_column(String(64), index=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), index=True)
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(32))
    uncertainty: Mapped[float] = mapped_column(Float)
    source_asset_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    calibration_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    verifier_id: Mapped[str | None] = mapped_column(String(128))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    authority_class: Mapped[str] = mapped_column(String(64))
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class ConsentGrantRow(Base):
    __tablename__ = "consent_grants"
    grant_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    subject_id: Mapped[str] = mapped_column(String(128), index=True)
    granted_by: Mapped[str] = mapped_column(String(128))
    purposes_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    audiences_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    scopes_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    derivative_policy_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revoked_by: Mapped[str | None] = mapped_column(String(128))
    state: Mapped[str] = mapped_column(String(32), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class SearchDocumentRow(Base):
    __tablename__ = "search_documents"
    document_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), index=True)
    asset_id: Mapped[str | None] = mapped_column(String(64), index=True)
    text: Mapped[str] = mapped_column(Text)
    terms_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    embedding_json: Mapped[list[float] | None] = mapped_column(JSON)
    spatial_bounds_json: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    temporal_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    temporal_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    policy_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    source_hash: Mapped[str] = mapped_column(String(64))


class ExportRow(Base):
    __tablename__ = "exports"
    export_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    format: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32), default="created")
    manifest_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    root_hash: Mapped[str] = mapped_column(String(64))
    path: Mapped[str] = mapped_column(Text)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class NotificationRow(Base):
    __tablename__ = "notifications"
    notification_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    recipient_id: Mapped[str] = mapped_column(String(128), index=True)
    channel: Mapped[str] = mapped_column(String(32))
    template_id: Mapped[str] = mapped_column(String(128))
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
    state: Mapped[str] = mapped_column(String(32), default="queued")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class CollaborationCommentRow(Base):
    __tablename__ = "collaboration_comments"
    comment_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    scene_commit_id: Mapped[str | None] = mapped_column(String(64), index=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), index=True)
    anchor_json: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    body: Mapped[str] = mapped_column(Text)
    body_hash: Mapped[str] = mapped_column(String(64))
    author_id: Mapped[str] = mapped_column(String(128))
    supersedes_comment_id: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class CollaborationTaskRow(Base):
    __tablename__ = "collaboration_tasks"
    task_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), index=True)
    state: Mapped[str] = mapped_column(String(32), default="open")
    priority: Mapped[str] = mapped_column(String(32), default="normal")
    title: Mapped[str] = mapped_column(String(512))
    description: Mapped[str] = mapped_column(Text)
    assignee_id: Mapped[str | None] = mapped_column(String(128))
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class ConstructionRecordRow(Base):
    __tablename__ = "construction_records"
    record_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    record_type: Mapped[str] = mapped_column(String(128), index=True)
    parent_id: Mapped[str | None] = mapped_column(String(64), index=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), index=True)
    state: Mapped[str] = mapped_column(String(64))
    data_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    evidence_asset_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MemoryRecordRow(Base):
    __tablename__ = "memory_records"
    record_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    record_type: Mapped[str] = mapped_column(String(128), index=True)
    subject_id: Mapped[str | None] = mapped_column(String(128), index=True)
    related_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    data_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    source_class: Mapped[str] = mapped_column(String(64))
    confidence: Mapped[float] = mapped_column(Float)
    evidence_asset_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    audience: Mapped[str] = mapped_column(String(32))
    generated_lineage_json: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class RetentionRuleRow(Base):
    __tablename__ = "retention_rules"
    retention_rule_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="RESTRICT"), index=True)
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.project_id", ondelete="RESTRICT"), index=True)
    retention_class: Mapped[str] = mapped_column(String(64))
    policy_source: Mapped[str] = mapped_column(Text)
    minimum_days: Mapped[int] = mapped_column(Integer)
    maximum_days: Mapped[int | None] = mapped_column(Integer)
    backup_expiry_days: Mapped[int] = mapped_column(Integer)
    deletion_mode: Mapped[str] = mapped_column(String(32))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(Integer)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    __table_args__ = (UniqueConstraint("tenant_id", "project_id", "retention_class", "version", name="uq_retention_rule_version"),)


class LegalHoldRow(Base):
    __tablename__ = "legal_holds"
    hold_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.tenant_id", ondelete="RESTRICT"), index=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.project_id", ondelete="RESTRICT"), index=True)
    resource_type: Mapped[str] = mapped_column(String(128))
    resource_id: Mapped[str] = mapped_column(String(128))
    reason: Mapped[str] = mapped_column(Text)
    authority_reference: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String(32), default="active")
    placed_by: Mapped[str] = mapped_column(String(128))
    placed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    released_by: Mapped[str | None] = mapped_column(String(128))
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (Index("ix_legal_hold_resource", "tenant_id", "project_id", "resource_type", "resource_id"),)


class BackupRunRow(Base):
    __tablename__ = "backup_runs"
    backup_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(String(64), index=True)
    profile: Mapped[str] = mapped_column(String(64))
    backup_path: Mapped[str] = mapped_column(Text)
    root_hash: Mapped[str] = mapped_column(String(64))
    schema_fingerprint: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(64), default="created")
    created_by: Mapped[str] = mapped_column(String(128))
    evidence: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    restore_rehearsed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class DeletionRequestRow(Base):
    __tablename__ = "deletion_requests"
    deletion_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    resource_type: Mapped[str] = mapped_column(String(128))
    resource_id: Mapped[str] = mapped_column(String(128))
    dry_run_report: Mapped[dict[str, Any]] = mapped_column(JSON)
    backup_reference: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(32))
    requested_by: Mapped[str] = mapped_column(String(128))
    approved_by: Mapped[str | None] = mapped_column(String(128))
    executed_by: Mapped[str | None] = mapped_column(String(128))
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    executed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class DeletionEvidenceRow(Base):
    __tablename__ = "deletion_evidence"
    evidence_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    deletion_id: Mapped[str] = mapped_column(ForeignKey("deletion_requests.deletion_id", ondelete="RESTRICT"), index=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    resource_type: Mapped[str] = mapped_column(String(128))
    resource_id: Mapped[str] = mapped_column(String(128))
    action: Mapped[str] = mapped_column(String(64))
    affected_references: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    key_ids: Mapped[list[str]] = mapped_column(JSON, default=list)
    residual_locations: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    backup_expiry_deadline: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    evidence_hash: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class KeyRotationRow(Base):
    __tablename__ = "key_rotations"
    rotation_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    old_key_id: Mapped[str] = mapped_column(String(128))
    new_key_id: Mapped[str] = mapped_column(String(128))
    object_count: Mapped[int] = mapped_column(Integer)
    ciphertext_unchanged: Mapped[bool] = mapped_column(Boolean)
    evidence_hash: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(32))
    rotated_by: Mapped[str] = mapped_column(String(128))
    rotated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    retired_key_destroyed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class QuotaPolicyRow(Base):
    __tablename__ = "quota_policies"
    quota_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str | None] = mapped_column(String(64), index=True)
    resource_type: Mapped[str] = mapped_column(String(64))
    unit: Mapped[str] = mapped_column(String(32))
    period_seconds: Mapped[int] = mapped_column(Integer)
    soft_limit: Mapped[float] = mapped_column(Float)
    hard_limit: Mapped[float] = mapped_column(Float)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)
    __table_args__ = (UniqueConstraint("tenant_id", "project_id", "resource_type", name="uq_quota_scope_resource"),)


class UsageLedgerRow(Base):
    __tablename__ = "usage_ledger"
    usage_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    project_id: Mapped[str] = mapped_column(String(64), index=True)
    operation_id: Mapped[str | None] = mapped_column(String(64), index=True)
    resource_type: Mapped[str] = mapped_column(String(64))
    quantity: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(32))
    unit_cost: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3))
    price_source_version: Mapped[str] = mapped_column(String(128))
    estimated: Mapped[bool] = mapped_column(Boolean)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=db_now)


class Database:
    def __init__(self, url: str, *, create: bool = False) -> None:
        self.url = url
        connect_args: dict[str, Any] = {}
        if url.startswith("sqlite"):
            connect_args["check_same_thread"] = False
            path = self.sqlite_path
            if path is not None:
                path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine(url, future=True, connect_args=connect_args)
        if url.startswith("sqlite"):
            event.listen(self.engine, "connect", _enable_sqlite_foreign_keys)
        self.session_factory = sessionmaker(bind=self.engine, expire_on_commit=False, class_=Session)
        if create:
            Base.metadata.create_all(self.engine)

    @property
    def sqlite_path(self) -> Path | None:
        prefix = "sqlite:///"
        if not self.url.startswith(prefix):
            return None
        raw = self.url[len(prefix) :]
        return Path(raw).resolve()

    def create_all(self) -> None:
        Base.metadata.create_all(self.engine)

    @contextmanager
    def session(self) -> Iterator[Session]:
        session = self.session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def dispose(self) -> None:
        self.engine.dispose()


def _enable_sqlite_foreign_keys(dbapi_connection: Any, connection_record: Any) -> None:
    del connection_record
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()
