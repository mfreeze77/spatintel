# Contributing

All changes require a requirement or ADR reference, tests, retained evidence for release claims, and compatible schema/migration updates. Provider/model additions fail closed until their manifests, hashes, licenses, permitted data classifications, regions, purposes, and retention terms are approved. Never modify an existing released migration; append a new migration.
