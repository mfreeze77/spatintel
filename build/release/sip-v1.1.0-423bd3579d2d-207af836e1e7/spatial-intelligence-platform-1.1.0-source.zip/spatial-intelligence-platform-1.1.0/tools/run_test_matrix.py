#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
REPORT_ROOT = ROOT / "build" / "reports" / "tests"


@dataclass(frozen=True)
class SuiteResult:
    name: str
    command: list[str]
    status: str
    exit_code: int
    elapsed_seconds: float
    tests: int
    failures: int
    errors: int
    skipped: int
    junit_path: str
    log_path: str


def _junit_counts(path: Path) -> tuple[int, int, int, int]:
    if not path.exists():
        return 0, 0, 0, 0
    root = ET.parse(path).getroot()
    suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))

    def total(key: str) -> int:
        return sum(int(float(item.attrib.get(key, "0"))) for item in suites)

    return total("tests"), total("failures"), total("errors"), total("skipped")


def _terminate_process_group(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=5)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)


def _suite(name: str, paths: Sequence[str], *, timeout_seconds: int) -> SuiteResult:
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    junit = REPORT_ROOT / f"{name}.xml"
    log = REPORT_ROOT / f"{name}.log"
    junit.unlink(missing_ok=True)
    command = [sys.executable, "-m", "pytest", "-q", *paths, f"--junitxml={junit}"]
    environment = dict(os.environ)
    environment.update({"PYTHONPATH": f"{ROOT / 'src'}:{ROOT}", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"})
    started = time.perf_counter()
    print(f"[test-matrix] starting {name}: {' '.join(command)}", flush=True)
    with log.open("wb") as output:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=environment,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            exit_code = process.wait(timeout=timeout_seconds)
            status = "passed" if exit_code == 0 else "failed"
        except subprocess.TimeoutExpired:
            _terminate_process_group(process)
            exit_code = 124
            status = "timeout"
            output.write(f"\nTIMEOUT after {timeout_seconds}s\n".encode("utf-8"))
    elapsed = time.perf_counter() - started
    tests, failures, errors, skipped = _junit_counts(junit)
    print(
        f"[test-matrix] {name}: {status}; tests={tests}; failures={failures}; "
        f"errors={errors}; skipped={skipped}; elapsed={elapsed:.2f}s",
        flush=True,
    )
    return SuiteResult(
        name=name,
        command=command,
        status=status,
        exit_code=exit_code,
        elapsed_seconds=round(elapsed, 6),
        tests=tests,
        failures=failures,
        errors=errors,
        skipped=skipped,
        junit_path=str(junit.relative_to(ROOT)),
        log_path=str(log.relative_to(ROOT)),
    )


def run(*, timeout_seconds: int = 180, jobs: int = 5) -> dict[str, object]:
    suites = [
        ("contract", ["tests/contract"]),
        ("integration", ["tests/integration"]),
        ("migration", ["tests/migration"]),
        ("security", ["tests/security"]),
        ("unit", ["tests/unit"]),
    ]
    by_name: dict[str, SuiteResult] = {}
    with ThreadPoolExecutor(max_workers=max(1, min(jobs, len(suites)))) as executor:
        futures = {
            executor.submit(_suite, name, paths, timeout_seconds=timeout_seconds): name
            for name, paths in suites
        }
        for future in as_completed(futures):
            result = future.result()
            by_name[result.name] = result
    results = [by_name[name] for name, _ in suites]
    status = "passed" if all(result.status == "passed" for result in results) else "failed"
    payload: dict[str, object] = {
        "schema": "sip.test-matrix/v1",
        "status": status,
        "python": sys.version,
        "plugin_autoload_disabled": True,
        "suite_process_isolation": True,
        "suite_parallelism": max(1, min(jobs, len(suites))),
        "results": [asdict(result) for result in results],
        "totals": {
            "tests": sum(result.tests for result in results),
            "failures": sum(result.failures for result in results),
            "errors": sum(result.errors for result in results),
            "skipped": sum(result.skipped for result in results),
            "elapsed_seconds": round(sum(result.elapsed_seconds for result in results), 6),
        },
    }
    destination = ROOT / "build" / "reports" / "test-matrix.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description="Run SIP test categories in isolated pytest processes.")
    parser.add_argument("--timeout", type=int, default=180, help="per-suite timeout in seconds")
    parser.add_argument("--jobs", type=int, default=5, help="number of isolated suites to execute concurrently")
    args = parser.parse_args()
    result = run(timeout_seconds=args.timeout, jobs=args.jobs)
    print(json.dumps(result, indent=2, sort_keys=True))
    if result["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
