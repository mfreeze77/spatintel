from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
HEX64 = re.compile(r"^[0-9a-f]{64}$")
HEX40 = re.compile(r"^[0-9a-f]{40}$")
MODEL_SUFFIXES = {".pt", ".pth", ".ckpt", ".safetensors", ".onnx", ".gguf", ".bin"}
VALID_APPROVALS = {"approved", "denied", "quarantined", "expired"}
INCOMPATIBLE_LICENSES = {"unknown", "research-only", "noncommercial", "non-commercial", "proprietary-unapproved"}


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f"{path}: root must be an object")
    return value


def validate(*, release: bool = False) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    def error(code: str, path: Path | str, message: str) -> None:
        errors.append({"code": code, "path": str(path), "message": message})

    def warning(code: str, path: Path | str, message: str) -> None:
        warnings.append({"code": code, "path": str(path), "message": message})

    source_lock = _load(ROOT / "third_party/sources/source-lock.json")
    names: set[str] = set()
    for source in source_lock.get("sources", []):
        name = str(source.get("name", ""))
        if not name or name in names:
            error("SOURCE_NAME_INVALID", "third_party/sources/source-lock.json", f"invalid/duplicate source name {name!r}")
        names.add(name)
        if not HEX40.fullmatch(str(source.get("revision", ""))):
            error("SOURCE_REVISION_UNPINNED", name, "source revision must be an exact 40-character Git commit")
        if not str(source.get("license", "")):
            error("SOURCE_LICENSE_MISSING", name, "source license is required")
        if not str(source.get("license_blob_sha", "")):
            error("SOURCE_LICENSE_EVIDENCE_MISSING", name, "license blob SHA is required")

    expected_lingbot = "1f480aeb8a47a24656090d46d053115b7fe60435"
    lingbot_lock = _load(ROOT / "adapters/lingbot-map/source.lock.json")
    if lingbot_lock.get("commit") != expected_lingbot:
        error("LINGBOT_REVISION_MISMATCH", "adapters/lingbot-map/source.lock.json", "authoritative LingBot commit changed")
    if lingbot_lock.get("checkpoint_approval") != "denied":
        error("LINGBOT_CHECKPOINT_MUST_DENY", "adapters/lingbot-map/source.lock.json", "checkpoint must remain denied until separately approved")
    dockerfile = (ROOT / "adapters/lingbot-map/Dockerfile").read_text()
    if expected_lingbot not in dockerfile:
        error("LINGBOT_DOCKER_REVISION_MISSING", "adapters/lingbot-map/Dockerfile", "Docker context does not enforce the pinned revision")
    if "@sha256:" not in dockerfile or re.search(r"@sha256:0{64}", dockerfile):
        error("LINGBOT_BASE_IMAGE_UNPINNED", "adapters/lingbot-map/Dockerfile", "base image must use a nonzero digest")
    warning(
        "LINGBOT_BASE_IMAGE_VULNERABILITIES_REQUIRE_RESCAN",
        "adapters/lingbot-map/Dockerfile",
        "deny-by-default adapter image must be rebuilt on a scan-clean CUDA/PyTorch baseline before approval",
    )

    provider_count = 0
    for path in sorted((ROOT / "third_party/providers").glob("*.json")):
        provider_count += 1
        manifest = _load(path)
        state = str(manifest.get("approval_state", ""))
        if state not in VALID_APPROVALS:
            error("PROVIDER_APPROVAL_INVALID", path, f"invalid approval state {state!r}")
        required = {
            "provider_id", "version", "source_url", "source_revision", "license_id", "approval_state",
            "allowed_classifications", "allowed_purposes", "allowed_regions", "retention_days",
        }
        missing = sorted(required - manifest.keys())
        if missing:
            error("PROVIDER_MANIFEST_INCOMPLETE", path, f"missing {missing}")
        if state == "approved":
            if manifest.get("license_id", "").lower() in INCOMPATIBLE_LICENSES | {"unknown"}:
                error("APPROVED_PROVIDER_LICENSE_INVALID", path, "approved provider has an unknown/incompatible license")
            if manifest.get("source_url") in {"UNRESOLVED", "", None}:
                error("APPROVED_PROVIDER_SOURCE_INVALID", path, "approved provider source must resolve")
        elif release and state != "denied":
            error("NONAPPROVED_PROVIDER_RELEASE", path, "release manifests must not contain executable quarantined/expired providers")

    model_count = 0
    for path in sorted((ROOT / "third_party/models").glob("*.json")):
        model_count += 1
        manifest = _load(path)
        state = str(manifest.get("approval_state", ""))
        if state not in VALID_APPROVALS:
            error("MODEL_APPROVAL_INVALID", path, f"invalid approval state {state!r}")
        required = {
            "model_id", "version", "checkpoint_hash", "code_revision", "code_license", "weights_license",
            "dataset_terms", "output_terms", "approval_state", "commercial_use", "allowed_purposes",
        }
        missing = sorted(required - manifest.keys())
        if missing:
            error("MODEL_MANIFEST_INCOMPLETE", path, f"missing {missing}")
        if state == "approved":
            if not HEX64.fullmatch(str(manifest.get("checkpoint_hash", ""))):
                error("APPROVED_MODEL_HASH_INVALID", path, "approved model requires an exact SHA-256 checkpoint hash")
            if str(manifest.get("weights_license", "")).lower() in INCOMPATIBLE_LICENSES:
                error("APPROVED_MODEL_LICENSE_INVALID", path, "approved model has incompatible/unknown weights rights")
            if not manifest.get("dataset_terms") or manifest.get("output_terms") in {"", "unknown", None}:
                error("APPROVED_MODEL_RIGHTS_INCOMPLETE", path, "approved model requires dataset and output-rights review")
        if release and state != "approved" and path.name != "lingbot-map-checkpoint.json":
            error("NONAPPROVED_MODEL_RELEASE", path, "nonapproved models cannot enter a release execution path")

    forbidden_weight_files = [
        path for path in ROOT.rglob("*")
        if path.is_file() and path.suffix.lower() in MODEL_SUFFIXES and "spec/" not in path.as_posix()
    ]
    for path in forbidden_weight_files:
        error("UNMANIFESTED_MODEL_FILE", path.relative_to(ROOT), "model/checkpoint binaries are forbidden in source and release trees")

    required_notices = [
        ROOT / "LICENSES/Apache-2.0-SIP.txt",
        ROOT / "LICENSES/Apache-2.0-LingBot-Map.txt",
        ROOT / "LICENSES/MIT-Polyform.txt",
        ROOT / "THIRD_PARTY_NOTICES.md",
    ]
    for path in required_notices:
        if not path.is_file() or path.stat().st_size == 0:
            error("NOTICE_MISSING", path.relative_to(ROOT), "required license/notice file is missing")

    if provider_count == 0:
        error("PROVIDER_MANIFESTS_MISSING", "third_party/providers", "at least one provider manifest is required")
    if model_count == 0:
        error("MODEL_MANIFESTS_MISSING", "third_party/models", "at least one model manifest is required")

    report = {
        "schema": "sip.governance-check/v1",
        "mode": "release" if release else "structural",
        "status": "passed" if not errors else "failed",
        "source_count": len(source_lock.get("sources", [])),
        "provider_count": provider_count,
        "model_count": model_count,
        "unmanifested_model_file_count": len(forbidden_weight_files),
        "errors": errors,
        "warnings": warnings,
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Fail-closed SIP source/model/provider governance gate")
    parser.add_argument("--release", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "build/reports/governance-check.json")
    args = parser.parse_args()
    report = validate(release=args.release)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))
    raise SystemExit(0 if report["status"] == "passed" else 1)


if __name__ == "__main__":
    main()
