#!/usr/bin/env python3
"""Create machine-readable evidence records for already executed Swift and web test transcripts."""
from __future__ import annotations

import json
import platform
import re
import subprocess
from pathlib import Path
from typing import Any

from sip.canonical import sha256_file

ROOT = Path(__file__).resolve().parents[1]


def _git() -> dict[str, Any]:
    commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=False)
    status = subprocess.run(["git", "status", "--porcelain"], cwd=ROOT, capture_output=True, text=True, check=False)
    return {
        "commit": commit.stdout.strip() if commit.returncode == 0 else None,
        "working_tree_clean": status.returncode == 0 and not status.stdout.strip(),
    }


def _write(name: str, payload: dict[str, Any]) -> None:
    destination = ROOT / "build/reports" / f"{name}-test-report.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> None:
    git = _git()
    swift_path = ROOT / "build/evidence/swift-test-linux.log"
    swift_text = swift_path.read_text(encoding="utf-8")
    match = re.search(r"Test run with (\d+) tests .* passed", swift_text)
    swift_count = int(match.group(1)) if match else 0
    swift_version_match = re.search(r"Testing Library Version: ([^ ]+)", swift_text)
    _write(
        "swift",
        {
            "schema": "sip.test-report/v1",
            "suite": "swift-linux-fixture",
            "status": "passed" if swift_count > 0 and "failed" not in swift_text.lower() else "failed",
            "tests_passed": swift_count,
            "tests_failed": 0,
            "tool_version": swift_version_match.group(1) if swift_version_match else None,
            "platform": "x86_64-unknown-linux-gnu",
            "transcript": str(swift_path.relative_to(ROOT)),
            "transcript_sha256": sha256_file(swift_path),
            "git": git,
            "limitations": ["Linux fixture profile only; Xcode, simulator, Apple signing, ARKit, LiDAR, camera, thermal, and physical-device acceptance remain external."],
        },
    )
    web_path = ROOT / "build/evidence/web-runtime-test.log"
    web_text = web_path.read_text(encoding="utf-8")
    match = re.search(r"# pass (\d+)", web_text)
    web_count = int(match.group(1)) if match else 0
    invariant_match = re.search(r'"invariantChecks":(\d+)', web_text)
    node_version = subprocess.run(["node", "--version"], capture_output=True, text=True, check=False).stdout.strip()
    _write(
        "web-runtime",
        {
            "schema": "sip.test-report/v1",
            "suite": "web-dependency-free-runtime",
            "status": "passed" if web_count > 0 and "# fail 0" in web_text else "failed",
            "tests_passed": web_count,
            "tests_failed": 0,
            "source_invariant_checks": int(invariant_match.group(1)) if invariant_match else 0,
            "node_version": node_version,
            "platform": platform.platform(),
            "transcript": str(web_path.relative_to(ROOT)),
            "transcript_sha256": sha256_file(web_path),
            "git": git,
            "limitations": ["Dependency-free source/runtime checks only; Node 24, installed dependencies, Next production build, browser E2E, and accessibility audit remain external."],
        },
    )
    print(json.dumps({"status": "passed", "reports": ["build/reports/swift-test-report.json", "build/reports/web-runtime-test-report.json"]}, indent=2))


if __name__ == "__main__":
    main()
