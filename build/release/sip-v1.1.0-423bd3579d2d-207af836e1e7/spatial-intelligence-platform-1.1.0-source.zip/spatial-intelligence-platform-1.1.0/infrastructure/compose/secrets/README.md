# Local Compose secrets

Run `python tools/bootstrap_secrets.py --output infrastructure/compose/secrets` before `docker compose up`.
The generated files are ignored by Git and use mode `0600`. They are development secrets only.
