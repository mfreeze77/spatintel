# Docker Compose local environment

The local profile runs PostgreSQL/PostGIS, Valkey, all logical API boundaries, four capability-scoped workers, and the web application. MinIO is opt-in because its upstream container repository is archived; it is allowed only for local compatibility testing.

```bash
python tools/bootstrap_secrets.py --output infrastructure/compose/secrets
docker compose --env-file infrastructure/compose/.env.example \
  -f infrastructure/compose/docker-compose.yml up --build
```

To exercise S3 compatibility locally, add `--profile local-object-store`. Production profiles must use a supported S3-compatible service or cloud object store and may not enable this MinIO service.

Only the control API and web UI bind host ports, and both bind to loopback by default. PostgreSQL and Valkey remain on an internal network. Development-header authentication is enabled only in this local Compose profile.
