# ADR-0004: Local object-store fixture and queue/cache selection

- Status: Accepted
- Date: 2026-07-27

## Context

The specification names MinIO for local S3-compatible development and permits Redis or an abstracted equivalent for queue/cache use. By July 2026 the public MinIO container repository is archived, while Valkey remains a BSD-licensed, community-maintained Redis-protocol-compatible datastore.

## Decision

1. Valkey is the default queue/cache implementation behind the SIP queue/cache abstraction.
2. The final public MinIO image is retained only as a digest-pinned, loopback-only, opt-in local compatibility fixture.
3. MinIO is denied in every production, hybrid, confidential, biometric, critical-infrastructure, and customer-data profile.
4. Production object storage must be a supported S3-compatible service or cloud object store with versioning, retention controls, encryption, audit integration, and an approved provider manifest.
5. Release checks fail if an image is not digest pinned, if its governance record is absent, or if a denied image appears in a production manifest.

## Consequences

Local S3 contract tests remain reproducible, but local MinIO results cannot be interpreted as production-security evidence. The storage adapter and preservation format remain provider-independent.
