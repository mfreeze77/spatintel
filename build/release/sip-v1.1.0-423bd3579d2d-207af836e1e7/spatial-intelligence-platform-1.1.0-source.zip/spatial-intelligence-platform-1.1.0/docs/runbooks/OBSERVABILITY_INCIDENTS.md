# Observability and SLO incident runbook

## Service objectives

The initial production service objective is **99.9% successful request availability over 30 days**, excluding explicitly classified client errors, and a **p95 API latency below one second** for control-plane requests. Geometry/GPU operation latency is measured separately by operation type and benchmark profile; HTTP acceptance of a durable job is not evidence that reconstruction completed.

Telemetry must never contain raw evidence bytes, credentials, private transcript text, biometric media, consent content, or unrestricted spatial coordinates. `src/sip/observability.py` redacts sensitive fields before JSON serialization, and the OpenTelemetry Collector deletes or hashes protected attributes before export.

## High error-budget burn

1. Confirm the alert is not caused by a telemetry-label or scrape failure.
2. Identify affected `service`, route template, deployment revision, and first failing request ID. Never paste authorization headers or request bodies into an incident channel.
3. Check readiness failures, database saturation, object-store errors, outbox growth, and dependency status.
4. Stop a damaging rollout with the documented Kubernetes rollback command. Do not roll back a database migration independently of its tested application compatibility window.
5. If tenant isolation, consent, evidence integrity, or deletion behavior may be affected, declare a security/privacy incident and disable the relevant provider/feature gate.
6. Retain logs, traces, audit-chain verification, image digest, configuration hash, and timeline in the incident evidence directory.

## High latency

Separate control-plane latency from queued geometry work. Check database query latency, connection-pool exhaustion, object-store response time, CPU/memory throttling, and high-cardinality search. Scale only after confirming idempotency and cost-budget admission controls remain active.

## Readiness failures

A database failure increments the `database` readiness counter; an object-store failure increments `object_store`. Keep the pod out of service until both probes pass. Never bypass readiness to restore traffic.

## Unhandled errors

Use the request ID and trace ID to find the structured event. The logger omits request bodies and credentials. Add a regression test before resolving the incident. If the error occurred during a durable operation, inspect its retained checkpoint and retry classification rather than replaying it manually.

## External validation

Production alert routing, paging delivery, long-term telemetry retention, backend access controls, and recovery of the telemetry backend require account-backed rehearsal and remain `EXTERNAL_VALIDATION_REQUIRED` until evidence is retained.
