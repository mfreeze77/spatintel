# External validation

Requirements below need evidence unavailable in the current environment.

No requirement is currently classified this way; this does **not** mean external validation is complete.
