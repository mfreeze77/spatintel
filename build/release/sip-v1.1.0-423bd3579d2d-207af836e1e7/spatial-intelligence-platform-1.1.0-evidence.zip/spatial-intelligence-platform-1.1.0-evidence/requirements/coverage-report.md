# Requirements coverage report

Generated: `2026-07-27T17:14:36.584003+00:00`

Total normative requirements: **1,028**

| Priority | NOT_STARTED | Total |
|---|---:|---:|
| P0 | 504 | 504 |
| P1 | 524 | 524 |

Verified: **0**
External validation required: **0**
Blocked: **0**

> Absence from the verified count is not evidence of implementation. Release-mode specification lint remains fail-closed.
